import SwiftUI
import UserNotifications

@main
struct FinanceTrackerApp: App {
    @State private var app = AppState()
    @AppStorage("appearance") private var appearance = "system"

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    private var scheme: ColorScheme? {
        switch appearance {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(app)
                .preferredColorScheme(scheme)
                .task { await app.bootstrap() }
        }
    }
}

struct RootView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        Group {
            switch app.phase {
            case .launching: ProgressView().controlSize(.large)
            case .signedOut: WelcomeView()
            case .ready: MainTabView()
            }
        }
        .animation(.smooth, value: app.phase)
    }
}

struct MainTabView: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Home", systemImage: "house.fill") }
            TransactionsView().tabItem { Label("History", systemImage: "list.bullet.rectangle") }
            AnalyticsView().tabItem { Label("Analytics", systemImage: "chart.pie.fill") }
            BudgetsView().tabItem { Label("Budgets", systemImage: "target") }
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape.fill") }
        }
    }
}
