import SwiftUI

struct BudgetsView: View {
    @Environment(AppState.self) private var app
    @State private var status: Fetched<BudgetStatusResponse>?
    @State private var editorCategory: String?
    @State private var showPicker = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            List {
                if let s = status, s.fromCache {
                    Label("Offline — showing your last known budget status.", systemImage: "wifi.slash")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if let error { Text(error).font(.footnote).foregroundStyle(.red) }

                if app.budgets.isEmpty {
                    ContentUnavailableView("No budgets yet", systemImage: "target",
                                           description: Text("Set a monthly limit for a category like Food or Shopping."))
                } else {
                    Section("This month") {
                        ForEach(rows) { item in
                            BudgetRow(item: item, currency: app.currency)
                                .contentShape(Rectangle())
                                .onTapGesture { editorCategory = item.category }
                                .swipeActions {
                                    Button(role: .destructive) { remove(item.category) } label: { Label("Delete", systemImage: "trash") }
                                }
                        }
                    }
                }
            }
            .navigationTitle("Budgets")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showPicker = true } label: { Image(systemName: "plus.circle.fill") }
                        .disabled(Categories.expense.allSatisfy { c in app.budgets.contains { $0.category == c } })
                }
            }
            .task(id: app.syncVersion) { await load() }
            .refreshable { await app.sync() }
            .sheet(isPresented: $showPicker) {
                BudgetEditor(category: nil) { await load() }
            }
            .sheet(item: Binding(get: { editorCategory.map { CategoryID(id: $0) } },
                                 set: { editorCategory = $0?.id })) { c in
                BudgetEditor(category: c.id) { await load() }
            }
        }
    }

    private struct CategoryID: Identifiable { let id: String }

    /// Server-computed status when available; budgets without status yet show as 0% used.
    private var rows: [BudgetStatus] {
        let byCat = Dictionary(uniqueKeysWithValues: (status?.value.items ?? []).map { ($0.category, $0) })
        return app.budgets.map { b in
            byCat[b.category] ?? BudgetStatus(category: b.category, limit: b.limit, spent: .zero,
                                              remaining: b.limit, percentUsed: 0, state: "ok")
        }
    }

    @MainActor private func load() async {
        do {
            status = try await app.fetchCached("/budgets/status", as: BudgetStatusResponse.self)
            error = nil
        } catch { if status == nil { self.error = nil } }
    }

    private func remove(_ category: String) {
        Task {
            do { try await app.removeBudget(category: category); await load() }
            catch { self.error = error.localizedDescription }
        }
    }
}

struct BudgetRow: View {
    let item: BudgetStatus
    let currency: String

    private var tint: Color { item.state == "exceeded" ? .red : (item.state == "warning" ? .orange : .green) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label(item.category, systemImage: Categories.icon(item.category)).font(.headline)
                Spacer()
                Text(String(format: "%.0f%%", item.percentUsed)).font(.subheadline.bold()).foregroundStyle(tint)
            }
            ProgressView(value: min(item.percentUsed, 100), total: 100).tint(tint)
            HStack {
                Text("Spent \(Fmt.money(item.spent, currency: currency))")
                Spacer()
                Text("Budget \(Fmt.money(item.limit, currency: currency))")
            }
            .font(.caption).foregroundStyle(.secondary)
            Text(item.state == "exceeded"
                 ? "Over budget by \(Fmt.money(Money(-item.remaining.value), currency: currency))"
                 : "\(Fmt.money(item.remaining, currency: currency)) remaining")
                .font(.caption.weight(.medium)).foregroundStyle(tint)
        }
        .padding(.vertical, 4)
    }
}

struct BudgetEditor: View {
    @Environment(AppState.self) private var app
    @Environment(\.dismiss) private var dismiss
    let category: String?
    let onSaved: () async -> Void
    @State private var selected = ""
    @State private var limitText = ""
    @State private var error: String?
    @State private var busy = false

    private var available: [String] {
        category != nil ? [category!] : Categories.expense.filter { c in !app.budgets.contains { $0.category == c } }
    }

    var body: some View {
        NavigationStack {
            Form {
                Picker("Category", selection: $selected) {
                    ForEach(available, id: \.self) { Text($0).tag($0) }
                }
                .disabled(category != nil)
                HStack {
                    Text(app.currency).foregroundStyle(.secondary)
                    TextField("Monthly limit", text: $limitText).keyboardType(.decimalPad)
                }
                if let error { Text(error).foregroundStyle(.red).font(.footnote) }
            }
            .navigationTitle(category == nil ? "New budget" : "Edit budget")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { Task { await save() } }.bold().disabled(busy)
                }
            }
            .onAppear {
                selected = category ?? available.first ?? ""
                if let c = category, let b = app.budgets.first(where: { $0.category == c }) {
                    limitText = Fmt.editableAmount(b.limit)
                }
            }
        }
    }

    @MainActor private func save() async {
        guard !selected.isEmpty else { error = "Choose a category."; return }
        guard let v = Fmt.parseAmount(limitText), v > 0, Fmt.hasAtMostTwoDecimals(v) else {
            error = "Enter a limit greater than 0 with at most 2 decimals."; return
        }
        busy = true
        defer { busy = false }
        do {
            try await app.setBudget(category: selected, limit: v)
            await onSaved()
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
