import SwiftUI
import UniformTypeIdentifiers

struct SettingsView: View {
    @Environment(AppState.self) private var app
    @AppStorage("appearance") private var appearance = "system"
    @AppStorage(NotificationManager.enabledKey) private var alertsOn = false

    @State private var showWalletEditor = false
    @State private var shareURL: URL?
    @State private var showImporter = false
    @State private var importedURL: URL?
    @State private var message: String?
    @State private var busy = false
    @State private var showDelete = false
    @State private var deletePassword = ""
    @State private var confirmSignOut = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Wallet") {
                    if let w = app.wallet {
                        LabeledContent("Name", value: w.name)
                        LabeledContent("Currency", value: w.currency)
                        LabeledContent("Starting balance", value: Fmt.money(w.startingBalance, currency: w.currency))
                    }
                    Button("Edit wallet…") { showWalletEditor = true }
                }

                Section("Budgets & notifications") {
                    NavigationLink("Manage budgets") { BudgetsView() }
                    Toggle("Budget alerts", isOn: Binding(get: { alertsOn }, set: { setAlerts($0) }))
                }

                Section("Appearance") {
                    Picker("Theme", selection: $appearance) {
                        Text("System").tag("system")
                        Text("Light").tag("light")
                        Text("Dark").tag("dark")
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    Button("Export transactions (CSV)") { exportCSV() }
                    Button("Download backup (JSON)") { Task { await downloadBackup() } }.disabled(busy)
                    Button("Restore from backup…") { showImporter = true }.disabled(busy)
                } header: { Text("Data") } footer: {
                    Text("Your data is stored on this device and synced to your account. A backup file lets you recover everything on a new device or after a mistake.")
                }

                Section("Account") {
                    LabeledContent("Email", value: app.email)
                    LabeledContent("Last synced", value: app.lastSync.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "Never")
                    if !app.outbox.isEmpty { LabeledContent("Waiting to sync", value: "\(app.outbox.count)") }
                    Button("Sync now") { Task { await app.sync() } }
                    Button("Sign out") { confirmSignOut = true }
                    Button("Delete account…", role: .destructive) { showDelete = true }
                }

                if let message {
                    Section { Text(message).font(.footnote).foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("Settings")
            .sheet(isPresented: $showWalletEditor) { WalletEditor() }
            .sheet(item: $shareURL) { ShareSheet(items: [$0]) }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                if case .success(let url) = result { importedURL = url }
            }
            .confirmationDialog("Restore backup", isPresented: Binding(get: { importedURL != nil },
                                                                       set: { if !$0 { importedURL = nil } }),
                                titleVisibility: .visible) {
                Button("Merge with current data") { restore(replace: false) }
                Button("Replace all current data", role: .destructive) { restore(replace: true) }
            } message: {
                Text("Merge adds or updates transactions from the backup. Replace deletes current transactions and budgets first.")
            }
            .confirmationDialog("Sign out?", isPresented: $confirmSignOut, titleVisibility: .visible) {
                Button("Sign out", role: .destructive) { Task { await app.signOut() } }
            } message: {
                Text("Data on this device is removed. It stays safe in your account and returns when you sign in again. Changes that haven't synced yet would be lost.")
            }
            .alert("Delete account", isPresented: $showDelete) {
                SecureField("Password", text: $deletePassword)
                Button("Delete forever", role: .destructive) { Task { await deleteAccount() } }
                Button("Cancel", role: .cancel) { deletePassword = "" }
            } message: {
                Text("This permanently deletes your account and every transaction on the server. Export a backup first if you want to keep a copy.")
            }
        }
    }

    private func setAlerts(_ on: Bool) {
        Task {
            if on {
                let ok = await NotificationManager.shared.requestAuthorization()
                alertsOn = ok
                message = ok ? nil : "Notifications are turned off for this app in iOS Settings."
            } else {
                NotificationManager.shared.disable()
                alertsOn = false
            }
        }
    }

    private func exportCSV() {
        do { shareURL = try app.makeCSV() } catch { message = error.localizedDescription }
    }

    @MainActor private func downloadBackup() async {
        busy = true; defer { busy = false }
        do { shareURL = try await app.downloadBackup() } catch { message = error.localizedDescription }
    }

    private func restore(replace: Bool) {
        guard let url = importedURL else { return }
        importedURL = nil
        Task {
            busy = true; defer { busy = false }
            do {
                try await app.restore(from: url, replace: replace)
                message = "Backup restored."
            } catch { message = error.localizedDescription }
        }
    }

    @MainActor private func deleteAccount() async {
        let pw = deletePassword
        deletePassword = ""
        do { try await app.deleteAccount(password: pw) } catch { message = error.localizedDescription }
    }
}

struct WalletEditor: View {
    @Environment(AppState.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var currency = "AED"
    @State private var balanceText = ""
    @State private var error: String?
    @State private var busy = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Wallet name") { TextField("Name", text: $name) }
                Section {
                    Picker("Currency", selection: $currency) {
                        ForEach(Currencies.common, id: \.code) { Text("\($0.code) — \($0.name)").tag($0.code) }
                    }
                } footer: {
                    Text("Changing currency only changes the label. Existing amounts are not converted.")
                }
                Section {
                    TextField("Starting balance", text: $balanceText).keyboardType(.decimalPad)
                } header: { Text("Starting balance") } footer: {
                    Text("Your transactions are never changed or reset. The available balance is recalculated from the new starting balance.")
                }
                if let error { Text(error).foregroundStyle(.red).font(.footnote) }
            }
            .navigationTitle("Edit wallet")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save") { Task { await save() } }.bold().disabled(busy) }
            }
            .onAppear {
                guard let w = app.wallet else { return }
                name = w.name; currency = w.currency; balanceText = Fmt.editableAmount(w.startingBalance)
            }
        }
    }

    @MainActor private func save() async {
        guard let v = Fmt.parseAmount(balanceText), Fmt.hasAtMostTwoDecimals(v) else {
            error = "Enter a valid starting balance with at most 2 decimals."; return
        }
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { error = "Enter a wallet name."; return }
        busy = true; defer { busy = false }
        do {
            try await app.updateWallet(name: trimmed, currency: currency, startingBalance: v)
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
