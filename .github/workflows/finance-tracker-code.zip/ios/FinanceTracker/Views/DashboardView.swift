import SwiftUI

struct DashboardView: View {
    @Environment(AppState.self) private var app
    @State private var formType: TxType?

    var body: some View {
        let b = app.balanceInfo
        let cur = app.currency
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    SyncBanner()

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Available balance").font(.subheadline).foregroundStyle(.white.opacity(0.8))
                        Text(Fmt.money(b.balance, currency: cur))
                            .font(.system(size: 38, weight: .bold, design: .rounded))
                            .minimumScaleFactor(0.6).lineLimit(1)
                            .contentTransition(.numericText())
                        Text("\(b.transactionCount) transaction\(b.transactionCount == 1 ? "" : "s")")
                            .font(.footnote).foregroundStyle(.white.opacity(0.8))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(22)
                    .background(LinearGradient(colors: [.indigo, .blue], startPoint: .topLeading, endPoint: .bottomTrailing),
                                in: RoundedRectangle(cornerRadius: 24, style: .continuous))

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatTile(title: "Starting balance", value: Fmt.money(b.startingBalance, currency: cur), icon: "flag.fill")
                        StatTile(title: "Total income", value: Fmt.money(b.totalIncome, currency: cur), icon: "arrow.down.circle.fill", tint: .green)
                        StatTile(title: "Total spent", value: Fmt.money(b.totalExpenses, currency: cur), icon: "arrow.up.circle.fill", tint: .red)
                        StatTile(title: "Transactions", value: "\(b.transactionCount)", icon: "number", tint: .purple)
                        StatTile(title: "Spent this week", value: Fmt.money(b.spentThisWeek, currency: cur), icon: "calendar", tint: .orange)
                        StatTile(title: "Spent this month", value: Fmt.money(b.spentThisMonth, currency: cur), icon: "calendar.badge.clock", tint: .pink)
                    }

                    HStack(spacing: 12) {
                        actionButton("Add expense", "minus.circle.fill", .red) { formType = .expense }
                        actionButton("Add income", "plus.circle.fill", .green) { formType = .income }
                    }

                    SummaryCard()

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Recent activity").font(.headline)
                        let recent = app.transactions.sorted { ($0.date, $0.id) > ($1.date, $1.id) }.prefix(5)
                        if recent.isEmpty {
                            Text("No transactions yet. Add your first expense or income above.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                        ForEach(Array(recent)) { TransactionRow(tx: $0, currency: cur) }
                    }
                    .card()
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle(app.wallet?.name ?? "Wallet")
            .refreshable { await app.sync() }
            .sheet(item: $formType) { TransactionFormView(type: $0, editing: nil) }
            .animation(.smooth, value: b.balance)
        }
    }

    private func actionButton(_ title: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity).padding(.vertical, 14)
                .background(tint.opacity(0.15), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .foregroundStyle(tint)
        }
    }
}

struct TransactionFormView: View {
    @Environment(AppState.self) private var app
    @Environment(\.dismiss) private var dismiss
    let type: TxType
    let editing: Transaction?

    @State private var amountText: String
    @State private var name: String
    @State private var category: String
    @State private var date: Date
    @State private var details: String
    @State private var method: String
    @State private var error: String?
    @State private var confirmDelete = false

    init(type: TxType, editing: Transaction?) {
        self.type = type
        self.editing = editing
        _amountText = State(initialValue: editing.map { Fmt.editableAmount($0.amount) } ?? "")
        _name = State(initialValue: editing?.name ?? "")
        _category = State(initialValue: editing?.category ?? Categories.all(for: type)[0])
        _date = State(initialValue: editing?.dateValue ?? .now)
        _details = State(initialValue: editing?.description ?? "")
        _method = State(initialValue: editing?.paymentMethod ?? "Card")
    }

    private var title: String {
        editing != nil ? "Edit transaction" : (type == .expense ? "Add expense" : "Add income")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text(app.currency).foregroundStyle(.secondary)
                        TextField("0.00", text: $amountText)
                            .keyboardType(.decimalPad)
                            .font(.title2.weight(.semibold))
                    }
                    TextField(type == .expense ? "What did you buy?" : "Where did it come from?", text: $name)
                }
                Section {
                    Picker("Category", selection: $category) {
                        ForEach(Categories.all(for: type), id: \.self) { c in
                            Label(c, systemImage: Categories.icon(c)).tag(c)
                        }
                    }
                    DatePicker("Date", selection: $date, in: ...Date.now, displayedComponents: .date)
                    Picker(type == .expense ? "Paid with" : "Received via", selection: $method) {
                        ForEach(Categories.paymentMethods, id: \.self) { Text($0).tag($0) }
                    }
                }
                Section("Description (optional)") {
                    TextField("Notes", text: $details, axis: .vertical).lineLimit(1...4)
                }
                if let error {
                    Section { Text(error).foregroundStyle(.red).font(.footnote) }
                }
                if editing != nil {
                    Section {
                        Button("Delete transaction", role: .destructive) { confirmDelete = true }
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save", action: save).bold() }
            }
            .confirmationDialog("Delete this transaction?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Delete", role: .destructive) {
                    if let id = editing?.id { app.delete(id) }
                    dismiss()
                }
            }
        }
    }

    private func save() {
        guard let amount = Fmt.parseAmount(amountText), amount > 0 else { error = "Enter an amount greater than 0."; return }
        guard Fmt.hasAtMostTwoDecimals(amount) else { error = "Use at most 2 decimal places."; return }
        guard amount <= 1_000_000_000 else { error = "That amount is too large."; return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { error = "Enter a name."; return }
        guard trimmed.count <= 100 else { error = "Name must be 100 characters or fewer."; return }
        guard details.count <= 500 else { error = "Description must be 500 characters or fewer."; return }
        app.save(Transaction(id: editing?.id ?? UUID().uuidString, type: type, name: trimmed,
                             amount: Money(amount), category: category, date: DateUtil.string(date),
                             description: details.trimmingCharacters(in: .whitespacesAndNewlines),
                             paymentMethod: method))
        dismiss()
    }
}
