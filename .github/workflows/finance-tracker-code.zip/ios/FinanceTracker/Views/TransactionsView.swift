import SwiftUI

private enum TypeFilter: String, CaseIterable, Identifiable {
    case all = "All", expense = "Expenses", income = "Income"
    var id: String { rawValue }
}

private enum DatePreset: String, CaseIterable, Identifiable {
    case all = "All time", week = "This week", month = "This month", last30 = "Last 30 days", custom = "Custom range"
    var id: String { rawValue }
}

private enum TxSort: String, CaseIterable, Identifiable {
    case newest = "Newest first", oldest = "Oldest first", highest = "Highest amount", lowest = "Lowest amount"
    var id: String { rawValue }
}

struct TransactionsView: View {
    @Environment(AppState.self) private var app
    @State private var search = ""
    @State private var typeFilter: TypeFilter = .all
    @State private var category = "All categories"
    @State private var preset: DatePreset = .all
    @State private var customFrom = Calendar.current.date(byAdding: .month, value: -1, to: .now) ?? .now
    @State private var customTo = Date()
    @State private var sort: TxSort = .newest
    @State private var editing: Transaction?
    @State private var addType: TxType?

    private var filtered: [Transaction] {
        var list = app.transactions
        if typeFilter != .all { list = list.filter { $0.type.rawValue == (typeFilter == .expense ? "expense" : "income") } }
        if category != "All categories" { list = list.filter { $0.category == category } }
        let q = search.trimmingCharacters(in: .whitespaces).lowercased()
        if !q.isEmpty {
            list = list.filter { $0.name.lowercased().contains(q) || $0.description.lowercased().contains(q)
                                 || $0.category.lowercased().contains(q) }
        }
        let (from, to) = dateBounds()
        list = list.filter { $0.date >= from && $0.date <= to }
        switch sort {
        case .newest: list.sort { ($0.date, $0.id) > ($1.date, $1.id) }
        case .oldest: list.sort { ($0.date, $0.id) < ($1.date, $1.id) }
        case .highest: list.sort { ($0.amount, $0.date) > ($1.amount, $1.date) }
        case .lowest: list.sort { ($0.amount, $0.date) < ($1.amount, $1.date) }
        }
        return list
    }

    private func dateBounds() -> (String, String) {
        let today = DateUtil.today()
        switch preset {
        case .all: return ("0000-01-01", "9999-12-31")
        case .week: return (DateUtil.weekStart(), today)
        case .month: return (DateUtil.monthStart(), today)
        case .last30: return (DateUtil.string(Calendar.current.date(byAdding: .day, value: -29, to: .now) ?? .now), today)
        case .custom: return (DateUtil.string(min(customFrom, customTo)), DateUtil.string(max(customFrom, customTo)))
        }
    }

    var body: some View {
        let items = filtered
        NavigationStack {
            List {
                if preset == .custom {
                    Section {
                        DatePicker("From", selection: $customFrom, in: ...Date.now, displayedComponents: .date)
                        DatePicker("To", selection: $customTo, in: ...Date.now, displayedComponents: .date)
                    }
                }
                Section("\(items.count) transaction\(items.count == 1 ? "" : "s")") {
                    if items.isEmpty {
                        ContentUnavailableView(app.transactions.isEmpty ? "No transactions yet" : "No matches",
                                               systemImage: "tray",
                                               description: Text(app.transactions.isEmpty ? "Add an expense or income to get started."
                                                                                           : "Try a different search or filter."))
                    }
                    ForEach(items) { tx in
                        TransactionRow(tx: tx, currency: app.currency)
                            .onTapGesture { editing = tx }
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) { app.delete(tx.id) } label: { Label("Delete", systemImage: "trash") }
                            }
                    }
                }
            }
            .navigationTitle("History")
            .searchable(text: $search, prompt: "Search name, category, notes")
            .refreshable { await app.sync() }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { filterMenu }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Add expense", systemImage: "minus.circle") { addType = .expense }
                        Button("Add income", systemImage: "plus.circle") { addType = .income }
                    } label: { Image(systemName: "plus.circle.fill") }
                }
            }
            .sheet(item: $editing) { TransactionFormView(type: $0.type, editing: $0) }
            .sheet(item: $addType) { TransactionFormView(type: $0, editing: nil) }
        }
    }

    private var filterMenu: some View {
        Menu {
            Picker("Sort", selection: $sort) { ForEach(TxSort.allCases) { Text($0.rawValue).tag($0) } }
            Picker("Type", selection: $typeFilter) { ForEach(TypeFilter.allCases) { Text($0.rawValue).tag($0) } }
            Picker("Category", selection: $category) {
                Text("All categories").tag("All categories")
                ForEach(Categories.expense + Categories.income, id: \.self) { Text($0).tag($0) }
            }
            Picker("Date", selection: $preset) { ForEach(DatePreset.allCases) { Text($0.rawValue).tag($0) } }
        } label: {
            Image(systemName: isFiltering ? "line.3.horizontal.decrease.circle.fill" : "line.3.horizontal.decrease.circle")
        }
    }

    private var isFiltering: Bool { typeFilter != .all || category != "All categories" || preset != .all || sort != .newest }
}
