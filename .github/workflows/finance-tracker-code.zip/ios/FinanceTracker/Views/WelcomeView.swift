import SwiftUI

/// First launch: (1) starting balance, currency, wallet name → (2) create account.
/// Returning users can switch to "Sign in".
struct WelcomeView: View {
    @Environment(AppState.self) private var app
    @State private var signingIn = false
    @State private var step = 0
    @State private var balanceText = ""
    @State private var currency = "AED"
    @State private var walletName = "My Wallet"
    @State private var email = ""
    @State private var password = ""
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    if signingIn { accountFields(title: "Sign in") }
                    else if step == 0 { walletFields } else { accountFields(title: "Create your account") }
                    if let error {
                        Text(error).font(.footnote).foregroundStyle(.red)
                    }
                    primaryButton
                    Button(signingIn ? "New here? Set up a wallet" : "I already have an account") {
                        signingIn.toggle(); step = 0; error = nil
                    }
                    .font(.footnote)
                    .frame(maxWidth: .infinity)
                }
                .padding(24)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Color(.systemGroupedBackground))
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: "wallet.pass.fill")
                .font(.system(size: 44))
                .foregroundStyle(.white)
                .frame(width: 84, height: 84)
                .background(LinearGradient(colors: [.indigo, .blue], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            Text(signingIn ? "Welcome back" : "Welcome").font(.largeTitle.bold())
            Text(signingIn ? "Sign in to see your wallet on this device."
                           : step == 0 ? "Let's set up your wallet. You can change any of this later in Settings."
                                       : "Your account keeps your data private and backed up.")
                .foregroundStyle(.secondary)
        }
    }

    private var walletFields: some View {
        VStack(spacing: 14) {
            field("Starting balance") {
                TextField("e.g. 5,000", text: $balanceText).keyboardType(.decimalPad)
            }
            field("Currency") {
                Picker("Currency", selection: $currency) {
                    ForEach(Currencies.common, id: \.code) { Text("\($0.code) — \($0.name)").tag($0.code) }
                }
                .pickerStyle(.menu).labelsHidden().frame(maxWidth: .infinity, alignment: .leading)
            }
            field("Wallet name") { TextField("My Wallet", text: $walletName) }
        }
    }

    private func accountFields(title: String) -> some View {
        VStack(spacing: 14) {
            Text(title).font(.headline).frame(maxWidth: .infinity, alignment: .leading)
            field("Email") {
                TextField("you@example.com", text: $email)
                    .textContentType(.emailAddress).keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
            }
            field("Password") {
                SecureField(signingIn ? "Password" : "At least 8 characters", text: $password)
                    .textContentType(signingIn ? .password : .newPassword)
            }
        }
    }

    private func field<Content: View>(_ label: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            content().padding(14).background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private var primaryButton: some View {
        Button {
            Task { await submit() }
        } label: {
            Group {
                if busy { ProgressView().tint(.white) }
                else { Text(signingIn ? "Sign in" : step == 0 ? "Continue" : "Create account & open dashboard") }
            }
            .font(.headline).foregroundStyle(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 16)
            .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .disabled(busy)
    }

    @MainActor private func submit() async {
        error = nil
        if !signingIn && step == 0 {
            guard let amount = Fmt.parseAmount(balanceText) else { error = "Enter your starting balance (0 is fine)."; return }
            guard Fmt.hasAtMostTwoDecimals(amount) else { error = "Use at most 2 decimal places."; return }
            guard !walletName.trimmingCharacters(in: .whitespaces).isEmpty else { error = "Give your wallet a name."; return }
            step = 1
            return
        }
        guard !email.isEmpty, !password.isEmpty else { error = "Enter your email and password."; return }
        busy = true
        defer { busy = false }
        do {
            if signingIn {
                try await app.login(email: email.trimmingCharacters(in: .whitespaces), password: password)
            } else {
                try await app.register(email: email.trimmingCharacters(in: .whitespaces), password: password,
                                       walletName: walletName.trimmingCharacters(in: .whitespaces),
                                       currency: currency, startingBalance: Fmt.parseAmount(balanceText) ?? 0)
            }
        } catch {
            self.error = error.localizedDescription
        }
    }
}
