import SwiftUI

extension View {
    func card() -> some View {
        self.padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

struct StatTile: View {
    let title: String
    let value: String
    var icon: String
    var tint: Color = .accentColor

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(tint)
                .frame(width: 30, height: 30)
                .background(tint.opacity(0.15), in: Circle())
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.headline).minimumScaleFactor(0.7).lineLimit(1)
        }
        .card()
    }
}

/// Shows offline / pending-sync state and any sync error.
struct SyncBanner: View {
    @Environment(AppState.self) private var app

    var body: some View {
        VStack(spacing: 8) {
            if !app.isOnline {
                row("wifi.slash", "Offline — changes are saved on this device and will sync automatically.", .orange)
            } else if !app.outbox.isEmpty {
                row("arrow.triangle.2.circlepath", "Syncing \(app.outbox.count) change\(app.outbox.count == 1 ? "" : "s")…", .blue)
            }
            if let message = app.banner {
                HStack {
                    Label(message, systemImage: "exclamationmark.triangle.fill").font(.footnote)
                    Spacer()
                    Button { app.banner = nil } label: { Image(systemName: "xmark") }
                }
                .padding(12)
                .background(Color.red.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
            }
        }
    }

    private func row(_ icon: String, _ text: String, _ color: Color) -> some View {
        Label(text, systemImage: icon)
            .font(.footnote)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct TransactionRow: View {
    let tx: Transaction
    let currency: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: Categories.icon(tx.category))
                .foregroundStyle(Categories.color(tx.category))
                .frame(width: 40, height: 40)
                .background(Categories.color(tx.category).opacity(0.15), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(tx.name).font(.body.weight(.medium)).lineLimit(1)
                Text("\(tx.category) · \(tx.dateValue.formatted(date: .abbreviated, time: .omitted))")
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            Text((tx.type == .income ? "+" : "−") + Fmt.money(tx.amount, currency: currency))
                .font(.body.weight(.semibold))
                .foregroundStyle(tx.type == .income ? Color.green : Color.primary)
        }
        .contentShape(Rectangle())
    }
}

/// The generated paragraph. Reloads on appear and whenever data syncs, so it always reflects stored transactions.
struct SummaryCard: View {
    @Environment(AppState.self) private var app
    @State private var result: Fetched<SummaryResponse>?
    @State private var error: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Financial summary", systemImage: "sparkles").font(.headline)
            if let r = result {
                Text(r.value.paragraph).font(.callout).fixedSize(horizontal: false, vertical: true)
                if r.fromCache {
                    Text("Offline — showing your last summary. It will refresh when you're back online.")
                        .font(.caption).foregroundStyle(.secondary)
                } else if !app.outbox.isEmpty {
                    Text("Some recent changes are still syncing and aren't included yet.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            } else if let error {
                Text(error).font(.callout).foregroundStyle(.secondary)
            } else {
                ProgressView()
            }
        }
        .card()
        .task(id: app.syncVersion) { await load() }
    }

    @MainActor private func load() async {
        do {
            result = try await app.fetchCached("/summary", as: SummaryResponse.self)
            error = nil
        } catch {
            if result == nil { self.error = "Connect to the internet once to generate your summary." }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

extension URL: Identifiable { public var id: String { absoluteString } }
