import SwiftUI
import Charts

private enum RangeOption: String, CaseIterable, Identifiable {
    case d7 = "7d", d30 = "30d", m3 = "3m", m6 = "6m", y1 = "1y", all = "all"
    var id: String { rawValue }
    var label: String {
        switch self {
        case .d7: return "7D"
        case .d30: return "30D"
        case .m3: return "3M"
        case .m6: return "6M"
        case .y1: return "1Y"
        case .all: return "All"
        }
    }
}

private enum GranularityOption: String, CaseIterable, Identifiable {
    case day, week, month, year
    var id: String { rawValue }
    var label: String { rawValue.capitalized }
    var unit: Calendar.Component {
        switch self {
        case .day: return .day
        case .week: return .weekOfYear
        case .month: return .month
        case .year: return .year
        }
    }
}

struct ChartPoint: Identifiable {
    let id: String
    let date: Date
    let value: Double
}

private struct LoadKey: Equatable {
    var range: String
    var granularity: String
    var version: Int
}

struct AnalyticsView: View {
    @Environment(AppState.self) private var app
    @State private var range: RangeOption = .d30
    @State private var granularity: GranularityOption = .day
    @State private var spending: SpendingSeries?
    @State private var categories: CategoryBreakdown?
    @State private var incomeExpense: IncomeExpenseSeries?
    @State private var history: BalanceHistory?
    @State private var fromCache = false
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    SyncBanner()
                    Picker("Range", selection: $range) {
                        ForEach(RangeOption.allCases) { Text($0.label).tag($0) }
                    }
                    .pickerStyle(.segmented)

                    SummaryCard()

                    if fromCache {
                        Label("Offline — charts show the last data loaded for this view.", systemImage: "wifi.slash")
                            .font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                    }
                    if let error {
                        Text(error).font(.footnote).foregroundStyle(.red)
                    }

                    spendingCard
                    categoryCard
                    incomeExpenseCard
                    balanceCard
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Analytics")
            .refreshable { await app.sync() }
            .task(id: LoadKey(range: range.rawValue, granularity: granularity.rawValue, version: app.syncVersion)) {
                await load()
            }
            .overlay { if loading && spending == nil { ProgressView() } }
        }
    }

    // MARK: Data

    @MainActor private func load() async {
        loading = true
        defer { loading = false }
        let r = URLQueryItem(name: "range", value: range.rawValue)
        let g = URLQueryItem(name: "granularity", value: granularity.rawValue)
        do {
            async let a = app.fetchCached("/analytics/spending-over-time", query: [r, g], as: SpendingSeries.self)
            async let b = app.fetchCached("/analytics/by-category", query: [r], as: CategoryBreakdown.self)
            async let c = app.fetchCached("/analytics/income-vs-expenses", query: [r, g], as: IncomeExpenseSeries.self)
            async let d = app.fetchCached("/analytics/balance-history", query: [r], as: BalanceHistory.self)
            let (sa, sb, sc, sd) = try await (a, b, c, d)
            spending = sa.value; categories = sb.value; incomeExpense = sc.value; history = sd.value
            fromCache = sa.fromCache || sb.fromCache || sc.fromCache || sd.fromCache
            error = nil
        } catch {
            self.error = spending == nil ? "Charts need an internet connection the first time you open them." : nil
        }
    }

    // MARK: Cards

    private var spendingCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Spending over time").font(.headline)
                Spacer()
                Picker("Granularity", selection: $granularity) {
                    ForEach(GranularityOption.allCases) { Text($0.label).tag($0) }
                }
                .pickerStyle(.menu)
            }
            if let s = spending {
                Text(Fmt.money(s.total, currency: app.currency)).font(.title2.bold())
                if s.total.value == 0 {
                    emptyState
                } else {
                    TimeSeriesChart(points: s.points.compactMap { p in
                        DateUtil.date(p.start).map { ChartPoint(id: p.bucket, date: $0, value: p.amount.double) }
                    }, kind: .bar, unit: granularity.unit, tint: .red, currency: app.currency)
                }
            } else { ProgressView() }
        }
        .card()
    }

    private var categoryCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Spending by category").font(.headline)
            if let c = categories {
                if c.categories.isEmpty {
                    emptyState
                } else {
                    ZStack {
                        Chart(c.categories) { item in
                            SectorMark(angle: .value("Amount", item.amount.double),
                                       innerRadius: .ratio(0.62), angularInset: 1.5)
                                .cornerRadius(4)
                                .foregroundStyle(by: .value("Category", item.category))
                        }
                        .chartForegroundStyleScale(domain: c.categories.map(\.category),
                                                   range: c.categories.map { Categories.color($0.category) })
                        .chartLegend(.hidden)
                        VStack(spacing: 2) {
                            Text("Total").font(.caption).foregroundStyle(.secondary)
                            Text(Fmt.money(c.total, currency: app.currency)).font(.headline)
                        }
                    }
                    .frame(height: 220)
                    ForEach(c.categories) { item in
                        HStack {
                            Circle().fill(Categories.color(item.category)).frame(width: 10, height: 10)
                            Text(item.category)
                            Spacer()
                            Text(Fmt.money(item.amount, currency: app.currency)).fontWeight(.medium)
                            Text(String(format: "%.0f%%", item.sharePercent)).foregroundStyle(.secondary).frame(width: 44, alignment: .trailing)
                        }
                        .font(.subheadline)
                    }
                }
            } else { ProgressView() }
        }
        .card()
    }

    private struct IEEntry: Identifiable {
        let id: String
        let date: Date
        let series: String
        let value: Double
    }

    private var incomeExpenseCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Income vs expenses").font(.headline)
            if let ie = incomeExpense {
                HStack(spacing: 24) {
                    VStack(alignment: .leading) {
                        Text("Income").font(.caption).foregroundStyle(.secondary)
                        Text(Fmt.money(ie.totalIncome, currency: app.currency)).font(.headline).foregroundStyle(.green)
                    }
                    VStack(alignment: .leading) {
                        Text("Expenses").font(.caption).foregroundStyle(.secondary)
                        Text(Fmt.money(ie.totalExpenses, currency: app.currency)).font(.headline).foregroundStyle(.red)
                    }
                }
                if ie.totalIncome.value == 0 && ie.totalExpenses.value == 0 {
                    emptyState
                } else {
                    let unit = GranularityOption(rawValue: ie.granularity)?.unit ?? .day
                    let entries: [IEEntry] = ie.points.flatMap { p -> [IEEntry] in
                        guard let d = DateUtil.date(p.start) else { return [] }
                        return [IEEntry(id: p.bucket + "i", date: d, series: "Income", value: p.income.double),
                                IEEntry(id: p.bucket + "e", date: d, series: "Expenses", value: p.expenses.double)]
                    }
                    Chart(entries) { e in
                        BarMark(x: .value("Period", e.date, unit: unit), y: .value("Amount", e.value))
                            .foregroundStyle(by: .value("Type", e.series))
                            .position(by: .value("Type", e.series))
                    }
                    .chartForegroundStyleScale(["Income": Color.green, "Expenses": Color.red])
                    .chartYAxis { compactYAxis }
                    .frame(height: 200)
                }
            } else { ProgressView() }
        }
        .card()
    }

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Balance history").font(.headline)
            if let h = history, let last = h.points.last {
                Text(Fmt.money(last.balance, currency: app.currency)).font(.title2.bold())
                TimeSeriesChart(points: h.points.compactMap { p in
                    DateUtil.date(p.date).map { ChartPoint(id: p.date, date: $0, value: p.balance.double) }
                }, kind: .line, unit: .day, tint: .blue, currency: app.currency)
            } else { ProgressView() }
        }
        .card()
    }

    private var emptyState: some View {
        Text("No data for this period yet.").font(.callout).foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, minHeight: 80)
    }

    @AxisContentBuilder private var compactYAxis: some AxisContent {
        AxisMarks { value in
            AxisGridLine()
            AxisValueLabel {
                if let d = value.as(Double.self) { Text(Fmt.compact(d)) }
            }
        }
    }
}

/// Bar or line chart with a touch/drag selection readout.
struct TimeSeriesChart: View {
    enum Kind { case bar, line }
    let points: [ChartPoint]
    let kind: Kind
    let unit: Calendar.Component
    let tint: Color
    let currency: String
    @State private var selected: Date?

    private var selectedPoint: ChartPoint? {
        guard let s = selected else { return nil }
        return points.min { abs($0.date.timeIntervalSince(s)) < abs($1.date.timeIntervalSince(s)) }
    }

    var body: some View {
        Chart {
            ForEach(points) { p in
                if kind == .bar {
                    BarMark(x: .value("Date", p.date, unit: unit), y: .value("Amount", p.value))
                        .foregroundStyle(tint.gradient)
                } else {
                    LineMark(x: .value("Date", p.date, unit: unit), y: .value("Amount", p.value))
                        .foregroundStyle(tint)
                    AreaMark(x: .value("Date", p.date, unit: unit), y: .value("Amount", p.value))
                        .foregroundStyle(tint.opacity(0.15))
                }
            }
            if let sp = selectedPoint {
                RuleMark(x: .value("Selected", sp.date, unit: unit))
                    .foregroundStyle(.secondary.opacity(0.4))
                    .annotation(position: .top, overflowResolution: .init(x: .fit(to: .chart), y: .disabled)) {
                        VStack(spacing: 2) {
                            Text(sp.date.formatted(date: .abbreviated, time: .omitted)).font(.caption2)
                            Text(Fmt.money(Money(Decimal(sp.value)), currency: currency)).font(.caption.bold())
                        }
                        .padding(6)
                        .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 8))
                    }
            }
        }
        .chartXSelection(value: $selected)
        .chartYAxis {
            AxisMarks { value in
                AxisGridLine()
                AxisValueLabel { if let d = value.as(Double.self) { Text(Fmt.compact(d)) } }
            }
        }
        .frame(height: 200)
    }
}
