import SwiftUI
import Observation
import Network

private struct WalletInput: Encodable {
    var name: String
    var currency: String
    var startingBalance: Money
    enum CodingKeys: String, CodingKey { case name, currency; case startingBalance = "starting_balance" }
}

private struct RegisterBody: Encodable {
    var email: String
    var password: String
    var wallet: WalletInput
}

/// Single source of truth for the UI.
/// - Transactions are stored on-device and shown instantly; every change is queued in `outbox`
///   and replayed to the server with idempotent PUT/DELETE calls, then the server state is pulled back.
/// - The server is authoritative: after each successful sync the local list is replaced by the server's.
@MainActor @Observable
final class AppState {
    enum Phase { case launching, signedOut, ready }

    var phase: Phase = .launching
    var wallet: Wallet?
    var email = ""
    var transactions: [Transaction] = []
    var budgets: [Budget] = []
    var serverBalance: Balance?
    var outbox: [OutboxOp] = []
    var isOnline = true
    var isSyncing = false
    var lastSync: Date?
    var syncVersion = 0          // bumps after each successful sync; analytics/summary reload on change
    var banner: String?

    @ObservationIgnored private var userId: String?
    @ObservationIgnored private var apiCache: [String: Data] = [:]
    @ObservationIgnored private var pendingResync = false
    @ObservationIgnored private var monitorStarted = false
    @ObservationIgnored private let monitor = NWPathMonitor()
    @ObservationIgnored private var sessionObserver: NSObjectProtocol?

    var currency: String { wallet?.currency ?? "AED" }

    // MARK: Launch

    func bootstrap() async {
        guard phase == .launching else { return }
        sessionObserver = NotificationCenter.default.addObserver(forName: .sessionExpired, object: nil,
                                                                 queue: .main) { [weak self] _ in
            Task { @MainActor in self?.phase = .signedOut }
        }
        let snap = LocalStore.load()
        userId = snap.userId
        email = snap.email
        wallet = snap.wallet
        transactions = snap.transactions
        budgets = snap.budgets
        outbox = snap.outbox
        apiCache = snap.apiCache
        lastSync = snap.lastSync
        if snap.userId != nil, await APIClient.shared.hasSession {
            phase = .ready
            startMonitor()
            await sync()
        } else {
            phase = .signedOut
        }
    }

    private func startMonitor() {
        guard !monitorStarted else { return }
        monitorStarted = true
        monitor.pathUpdateHandler = { [weak self] path in
            let online = path.status == .satisfied
            Task { @MainActor in
                guard let self else { return }
                let regained = online && !self.isOnline
                self.isOnline = online
                if regained { await self.sync() }
            }
        }
        monitor.start(queue: DispatchQueue(label: "network-monitor"))
    }

    // MARK: Auth

    func register(email: String, password: String, walletName: String, currency: String,
                  startingBalance: Decimal) async throws {
        let body = try JSONEncoder().encode(RegisterBody(
            email: email, password: password,
            wallet: WalletInput(name: walletName, currency: currency, startingBalance: Money(startingBalance))))
        adopt(try await APIClient.shared.authenticate("/auth/register", body: body))
    }

    func login(email: String, password: String) async throws {
        let body = try JSONEncoder().encode(["email": email, "password": password])
        adopt(try await APIClient.shared.authenticate("/auth/login", body: body))
    }

    private func adopt(_ r: AuthResponse) {
        if userId != r.user.id { wipeLocalData() }   // never mix two users' data on one device
        userId = r.user.id
        email = r.user.email
        wallet = r.wallet
        phase = .ready
        persist()
        startMonitor()
        Task { await sync() }
    }

    func signOut() async {
        await sync()                                  // try to flush pending changes first
        await APIClient.shared.logout()
        wipeLocalData()
        phase = .signedOut
    }

    func deleteAccount(password: String) async throws {
        let body = try JSONEncoder().encode(["password": password])
        try await APIClient.shared.sendNoContent("DELETE", "/me", body: body)
        await APIClient.shared.clearSession()
        wipeLocalData()
        phase = .signedOut
    }

    private func wipeLocalData() {
        userId = nil; email = ""; wallet = nil; transactions = []; budgets = []
        outbox = []; apiCache = [:]; serverBalance = nil; lastSync = nil; banner = nil
        LocalStore.delete()
        UserDefaults.standard.removeObject(forKey: "notifiedBudgetKeys")
    }

    // MARK: Derived numbers (instant, on-device; replaced by the server's figures after each sync)

    var balanceInfo: Balance {
        if outbox.isEmpty, let sb = serverBalance { return sb }
        return localBalance()
    }

    private func localBalance() -> Balance {
        var income = Decimal(0), expenses = Decimal(0), week = Decimal(0), month = Decimal(0)
        let ws = DateUtil.weekStart(), ms = DateUtil.monthStart()
        for t in transactions {
            if t.type == .income { income += t.amount.value; continue }
            expenses += t.amount.value
            if t.date >= ws { week += t.amount.value }
            if t.date >= ms { month += t.amount.value }
        }
        let start = wallet?.startingBalance.value ?? 0
        return Balance(currency: currency, startingBalance: Money(start), totalIncome: Money(income),
                       totalExpenses: Money(expenses), balance: Money(start + income - expenses),
                       transactionCount: transactions.count, spentThisWeek: Money(week),
                       spentThisMonth: Money(month))
    }

    // MARK: Transactions (add / edit / delete)

    func save(_ tx: Transaction) {
        if let i = transactions.firstIndex(where: { $0.id == tx.id }) { transactions[i] = tx } else { transactions.append(tx) }
        outbox.removeAll { $0.txId == tx.id }
        outbox.append(.upsert(tx))
        afterLocalChange()
    }

    func delete(_ id: String) {
        transactions.removeAll { $0.id == id }
        outbox.removeAll { $0.txId == id }
        outbox.append(.delete(id))
        afterLocalChange()
    }

    private func afterLocalChange() {
        serverBalance = nil
        persist()
        NotificationManager.shared.evaluate(budgets: budgets, transactions: transactions, currency: currency)
        Task { await sync() }
    }

    // MARK: Sync

    func sync() async {
        guard phase == .ready else { return }
        if isSyncing { pendingResync = true; return }
        isSyncing = true
        do {
            try await flushOutbox()
            try await pull()
            isOnline = true
        } catch let e as APIError {
            if e.isConnectivity { isOnline = false } else if case .unauthorized = e { } else { banner = e.errorDescription }
        } catch {
            banner = error.localizedDescription
        }
        isSyncing = false
        if pendingResync { pendingResync = false; await sync() }
    }

    private func removeOp(_ op: OutboxOp) {
        if let i = outbox.firstIndex(of: op) { outbox.remove(at: i) }
    }

    private func flushOutbox() async throws {
        while let op = outbox.first {
            do {
                switch op {
                case .upsert(let t):
                    let body = try JSONEncoder().encode(t)
                    let _: Transaction = try await APIClient.shared.send("PUT", "/transactions/\(t.id)", body: body)
                case .delete(let id):
                    try await APIClient.shared.sendNoContent("DELETE", "/transactions/\(id)")
                }
                removeOp(op)
            } catch let e as APIError {
                // A 4xx (other than auth/rate-limit) will never succeed on retry: drop it and tell the user.
                if case .server(let status, _, let message) = e, (400..<500).contains(status), status != 429 {
                    removeOp(op)
                    banner = "A change couldn't be saved and was discarded: \(message)"
                    continue
                }
                throw e
            }
        }
        persist()
    }

    private func pull() async throws {
        let api = APIClient.shared
        let w: Wallet = try await api.get("/wallet")
        let b: BudgetList = try await api.get("/budgets")
        var all: [Transaction] = []
        while true {
            let page: TransactionPage = try await api.get("/transactions", query: [
                URLQueryItem(name: "limit", value: "500"),
                URLQueryItem(name: "offset", value: String(all.count)),
                URLQueryItem(name: "sort", value: "oldest")])
            all += page.items
            if page.items.isEmpty || all.count >= page.total { break }
        }
        let bal: Balance = try await api.get("/balance")

        // Re-apply anything the user changed while we were pulling.
        for op in outbox {
            switch op {
            case .upsert(let t):
                if let i = all.firstIndex(where: { $0.id == t.id }) { all[i] = t } else { all.append(t) }
            case .delete(let id):
                all.removeAll { $0.id == id }
            }
        }
        wallet = w
        budgets = b.items
        transactions = all
        serverBalance = outbox.isEmpty ? bal : nil
        lastSync = Date()
        syncVersion += 1
        persist()
        NotificationManager.shared.evaluate(budgets: budgets, transactions: transactions, currency: currency)
    }

    // MARK: Server-validated settings (need a connection)

    func updateWallet(name: String, currency: String, startingBalance: Decimal) async throws {
        struct Update: Encodable {
            var name: String
            var currency: String
            var startingBalance: Money
            enum CodingKeys: String, CodingKey { case name, currency; case startingBalance = "starting_balance" }
        }
        let body = try JSONEncoder().encode(Update(name: name, currency: currency, startingBalance: Money(startingBalance)))
        wallet = try await APIClient.shared.send("PUT", "/wallet", body: body)
        serverBalance = nil
        persist()
        await sync()
    }

    func setBudget(category: String, limit: Decimal) async throws {
        let body = try JSONEncoder().encode(["limit": Money(limit).wire])
        try await APIClient.shared.sendNoContent("PUT", "/budgets/\(category)", body: body)
        let list: BudgetList = try await APIClient.shared.get("/budgets")
        budgets = list.items
        syncVersion += 1
        persist()
        NotificationManager.shared.evaluate(budgets: budgets, transactions: transactions, currency: currency)
    }

    func removeBudget(category: String) async throws {
        try await APIClient.shared.sendNoContent("DELETE", "/budgets/\(category)")
        budgets.removeAll { $0.category == category }
        syncVersion += 1
        persist()
    }

    // MARK: Cached analytics fetch (falls back to the last good response when offline)

    func fetchCached<T: Decodable>(_ path: String, query: [URLQueryItem] = [], as type: T.Type = T.self) async throws -> Fetched<T> {
        let key = path + "?" + query.map { "\($0.name)=\($0.value ?? "")" }.sorted().joined(separator: "&")
        do {
            let data = try await APIClient.shared.getData(path, query: query)
            let value = try APIClient.decoder.decode(T.self, from: data)
            apiCache[key] = data
            persist()
            return Fetched(value: value, fromCache: false)
        } catch let e as APIError where e.isConnectivity {
            isOnline = false
            if let data = apiCache[key], let value = try? APIClient.decoder.decode(T.self, from: data) {
                return Fetched(value: value, fromCache: true)
            }
            throw e
        }
    }

    // MARK: Export, backup, restore

    func makeCSV() throws -> URL {
        func esc(_ s: String) -> String {
            var v = s
            if let f = v.first, "=+-@\t\r".contains(f) { v = "'" + v }       // block spreadsheet formula injection
            return (v.contains(",") || v.contains("\"") || v.contains("\n"))
                ? "\"" + v.replacingOccurrences(of: "\"", with: "\"\"") + "\"" : v
        }
        var lines = ["id,date,type,name,category,amount,currency,payment_method,description"]
        for t in transactions.sorted(by: { ($0.date, $0.id) > ($1.date, $1.id) }) {
            lines.append([t.id, t.date, t.type.rawValue, esc(t.name), esc(t.category), t.amount.wire,
                          currency, esc(t.paymentMethod), esc(t.description)].joined(separator: ","))
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("transactions-\(DateUtil.today()).csv")
        try lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    func downloadBackup() async throws -> URL {
        let data = try await APIClient.shared.getData("/backup")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("finance-backup-\(DateUtil.today()).json")
        try data.write(to: url, options: .completeFileProtection)
        return url
    }

    func restore(from fileURL: URL, replace: Bool) async throws {
        await sync()                                   // make sure nothing pending would be lost or duplicated
        guard outbox.isEmpty else {
            throw APIError.server(status: 0, code: "pending", message: "Wait for pending changes to sync, then try again.")
        }
        let scoped = fileURL.startAccessingSecurityScopedResource()
        defer { if scoped { fileURL.stopAccessingSecurityScopedResource() } }
        let raw = try Data(contentsOf: fileURL)
        let backup = try JSONSerialization.jsonObject(with: raw)
        let body = try JSONSerialization.data(withJSONObject: ["mode": replace ? "replace" : "merge", "backup": backup])
        try await APIClient.shared.sendNoContent("POST", "/restore", body: body)
        await sync()
    }

    // MARK: Persistence

    private func persist() {
        LocalStore.save(Snapshot(userId: userId, email: email, wallet: wallet, transactions: transactions,
                                 budgets: budgets, outbox: outbox, apiCache: apiCache, lastSync: lastSync))
    }
}

