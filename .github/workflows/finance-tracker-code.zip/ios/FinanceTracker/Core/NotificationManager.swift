import Foundation
import UserNotifications

/// Local budget alerts. Fires when a monthly category budget first reaches 80% ("approaching")
/// or goes over 100% ("exceeded"). Each level is announced once per category per month.
/// Alerts are evaluated whenever transactions change or sync; there is no server push (APNs) yet.
@MainActor
final class NotificationManager {
    static let shared = NotificationManager()
    private let notifiedKey = "notifiedBudgetKeys"
    static let enabledKey = "budgetAlertsEnabled"

    var isEnabled: Bool { UserDefaults.standard.bool(forKey: Self.enabledKey) }

    func requestAuthorization() async -> Bool {
        let granted = (try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound, .badge])) ?? false
        UserDefaults.standard.set(granted, forKey: Self.enabledKey)
        return granted
    }

    func disable() { UserDefaults.standard.set(false, forKey: Self.enabledKey) }

    func evaluate(budgets: [Budget], transactions: [Transaction], currency: String) {
        guard isEnabled, !budgets.isEmpty else { return }
        let monthStart = DateUtil.monthStart(), today = DateUtil.today()
        let monthKey = String(monthStart.prefix(7))
        var spent: [String: Decimal] = [:]
        for t in transactions where t.type == .expense && t.date >= monthStart && t.date <= today {
            spent[t.category, default: 0] += t.amount.value
        }
        var notified = Set(UserDefaults.standard.stringArray(forKey: notifiedKey) ?? [])
        notified = notified.filter { $0.hasPrefix(monthKey) }          // forget previous months

        for b in budgets where b.limit.value > 0 {
            let s = spent[b.category] ?? 0
            let percent = NSDecimalNumber(decimal: s / b.limit.value * 100).doubleValue
            let level: String? = s > b.limit.value ? "exceeded" : (percent >= 80 ? "warning" : nil)
            guard let level else { continue }
            let key = "\(monthKey)|\(b.category)|\(level)"
            if notified.contains(key) { continue }
            notified.insert(key)
            if level == "exceeded" { notified.insert("\(monthKey)|\(b.category)|warning") }

            let content = UNMutableNotificationContent()
            content.sound = .default
            if level == "exceeded" {
                content.title = "\(b.category) budget exceeded"
                content.body = "You've spent \(Fmt.money(Money(s), currency: currency)) of your \(Fmt.money(b.limit, currency: currency)) budget."
            } else {
                content.title = "Nearing your \(b.category) budget"
                content.body = "You've used \(Int(percent))% of your \(Fmt.money(b.limit, currency: currency)) budget this month."
            }
            UNUserNotificationCenter.current().add(UNNotificationRequest(
                identifier: UUID().uuidString, content: content, trigger: nil))
        }
        UserDefaults.standard.set(Array(notified), forKey: notifiedKey)
    }
}

/// Lets alerts appear as banners while the app is open.
final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}
