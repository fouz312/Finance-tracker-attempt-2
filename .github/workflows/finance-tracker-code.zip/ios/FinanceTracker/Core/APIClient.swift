import Foundation

extension Notification.Name {
    static let sessionExpired = Notification.Name("sessionExpired")
}

enum APIError: LocalizedError {
    case offline
    case unauthorized
    case server(status: Int, code: String, message: String)
    case invalidResponse

    var isConnectivity: Bool { if case .offline = self { return true } else { return false } }

    var errorDescription: String? {
        switch self {
        case .offline: return "You're offline. This needs an internet connection."
        case .unauthorized: return "Your session has expired. Please sign in again."
        case .server(_, _, let message): return message
        case .invalidResponse: return "The server sent an unexpected response."
        }
    }
}

private struct ErrorEnvelope: Decodable {
    struct Body: Decodable { let code: String; let message: String }
    let error: Body
}

/// All networking. Access token is kept in memory; the refresh token is in the Keychain.
/// A 401 triggers one automatic refresh-and-retry; if refresh is rejected the session ends.
actor APIClient {
    static let shared = APIClient()
    static let decoder = JSONDecoder()

    private let session: URLSession
    private var accessToken: String?
    private var refreshToken: String? = Keychain.get("refreshToken")
    private var refreshTask: Task<Void, Error>?

    init() {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 20
        cfg.waitsForConnectivity = false
        cfg.urlCache = nil                       // never cache financial responses on disk
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: cfg)
    }

    var hasSession: Bool { refreshToken != nil }

    // MARK: Public helpers

    func get<T: Decodable>(_ path: String, query: [URLQueryItem] = []) async throws -> T {
        try decode(try await data("GET", path, query: query, body: nil))
    }

    func getData(_ path: String, query: [URLQueryItem] = []) async throws -> Data {
        try await data("GET", path, query: query, body: nil)
    }

    func send<T: Decodable>(_ method: String, _ path: String, body: Data?) async throws -> T {
        try decode(try await data(method, path, query: [], body: body))
    }

    func sendNoContent(_ method: String, _ path: String, body: Data? = nil) async throws {
        _ = try await data(method, path, query: [], body: body)
    }

    func authenticate(_ path: String, body: Data) async throws -> AuthResponse {
        let raw = try await perform("POST", path, query: [], body: body, auth: false)
        let response: AuthResponse = try decode(raw)
        setTokens(access: response.accessToken, refresh: response.refreshToken)
        return response
    }

    func logout() async {
        if let rt = refreshToken, let body = try? JSONEncoder().encode(["refresh_token": rt]) {
            _ = try? await perform("POST", "/auth/logout", query: [], body: body, auth: false)
        }
        clearSession()
    }

    func clearSession() {
        accessToken = nil
        refreshToken = nil
        Keychain.delete("refreshToken")
    }

    // MARK: Core

    private func decode<T: Decodable>(_ data: Data) throws -> T {
        do { return try APIClient.decoder.decode(T.self, from: data) } catch { throw APIError.invalidResponse }
    }

    private func setTokens(access: String, refresh: String) {
        accessToken = access
        refreshToken = refresh
        Keychain.set(refresh, for: "refreshToken")
    }

    private func data(_ method: String, _ path: String, query: [URLQueryItem], body: Data?) async throws -> Data {
        if accessToken == nil { try await refreshAccess() }
        do {
            return try await perform(method, path, query: query, body: body, auth: true)
        } catch APIError.unauthorized {
            try await refreshAccess()
            return try await perform(method, path, query: query, body: body, auth: true)
        }
    }

    private func refreshAccess() async throws {
        if let running = refreshTask { return try await running.value }
        guard let rt = refreshToken else { throw APIError.unauthorized }
        let task = Task { try await self.performRefresh(rt) }
        refreshTask = task
        defer { refreshTask = nil }
        try await task.value
    }

    private func performRefresh(_ rt: String) async throws {
        do {
            let body = try JSONEncoder().encode(["refresh_token": rt])
            let raw = try await perform("POST", "/auth/refresh", query: [], body: body, auth: false)
            struct Tokens: Decodable { let access_token: String; let refresh_token: String }
            let t: Tokens = try decode(raw)
            setTokens(access: t.access_token, refresh: t.refresh_token)
        } catch APIError.server(let status, _, _) where status == 401 {
            clearSession()
            await MainActor.run { NotificationCenter.default.post(name: .sessionExpired, object: nil) }
            throw APIError.unauthorized
        }
    }

    private func perform(_ method: String, _ path: String, query: [URLQueryItem],
                         body: Data?, auth: Bool) async throws -> Data {
        var comps = URLComponents(url: Config.apiBaseURL.appendingPathComponent(path),
                                  resolvingAgainstBaseURL: false)!
        comps.queryItems = query.isEmpty ? nil : query
        var req = URLRequest(url: comps.url!)
        req.httpMethod = method
        req.httpBody = body
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        req.setValue(DateUtil.today(), forHTTPHeaderField: "X-Client-Date")
        if auth, let token = accessToken { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: req)
        } catch let error as URLError {
            switch error.code {
            case .notConnectedToInternet, .networkConnectionLost, .timedOut, .cannotFindHost,
                 .cannotConnectToHost, .dataNotAllowed, .dnsLookupFailed, .internationalRoamingOff:
                throw APIError.offline
            default: throw APIError.offline
            }
        }
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        if (200..<300).contains(http.statusCode) { return data }
        if http.statusCode == 401 && auth { throw APIError.unauthorized }
        let env = try? APIClient.decoder.decode(ErrorEnvelope.self, from: data)
        throw APIError.server(status: http.statusCode, code: env?.error.code ?? "error",
                              message: env?.error.message ?? "Request failed (\(http.statusCode)).")
    }
}
