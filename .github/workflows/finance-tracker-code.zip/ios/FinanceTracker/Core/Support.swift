import Foundation
import Security

// MARK: - Configuration

enum Config {
    /// Debug builds talk to a local server (see README). Release builds MUST use an https:// URL.
    static let apiBaseURL: URL = {
        #if DEBUG
        return URL(string: "http://localhost:8000/api/v1")!
        #else
        return URL(string: "https://api.example.com/api/v1")!   // <- replace with your deployed API
        #endif
    }()
}

// MARK: - Dates (the API uses yyyy-MM-dd in the user's local calendar day; weeks start on Monday)

enum DateUtil {
    static let calendar: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = .current
        c.firstWeekday = 2
        return c
    }()

    static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.calendar = Calendar(identifier: .gregorian)
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = .current
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()

    static func string(_ d: Date) -> String { formatter.string(from: d) }
    static func date(_ s: String) -> Date? { formatter.date(from: s) }
    static func today() -> String { string(.now) }

    static func weekStart(_ ref: Date = .now) -> String {
        string(calendar.dateInterval(of: .weekOfYear, for: ref)?.start ?? ref)
    }

    static func monthStart(_ ref: Date = .now) -> String {
        string(calendar.dateInterval(of: .month, for: ref)?.start ?? ref)
    }
}

// MARK: - Formatting & parsing

enum Fmt {
    static func money(_ m: Money, currency: String) -> String {
        let f = NumberFormatter()
        f.numberStyle = .currency
        f.currencyCode = currency
        return f.string(from: NSDecimalNumber(decimal: m.value)) ?? "\(m.wire) \(currency)"
    }

    static func compact(_ v: Double) -> String {
        v.formatted(.number.notation(.compactName).precision(.fractionLength(0...1)))
    }

    /// Parses what a user typed, honouring their locale's decimal separator.
    static func parseAmount(_ text: String) -> Decimal? {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.generatesDecimalNumbers = true
        f.locale = .current
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty, let n = f.number(from: trimmed) as? NSDecimalNumber else { return nil }
        return n.decimalValue
    }

    static func hasAtMostTwoDecimals(_ d: Decimal) -> Bool {
        var source = d
        var rounded = Decimal()
        NSDecimalRound(&rounded, &source, 2, .plain)
        return rounded == d
    }

    /// Editable text for a stored amount (no grouping separators, locale decimal mark).
    static func editableAmount(_ m: Money) -> String {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.usesGroupingSeparator = false
        f.minimumFractionDigits = 0
        f.maximumFractionDigits = 2
        return f.string(from: NSDecimalNumber(decimal: m.value)) ?? m.wire
    }
}

// MARK: - Keychain (refresh token lives here, never in UserDefaults)

enum Keychain {
    private static let service = "com.example.FinanceTracker"

    static func set(_ value: String, for key: String) {
        let base: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                   kSecAttrService as String: service,
                                   kSecAttrAccount as String: key]
        SecItemDelete(base as CFDictionary)
        var add = base
        add[kSecValueData as String] = Data(value.utf8)
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(add as CFDictionary, nil)
    }

    static func get(_ key: String) -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: key,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var out: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(_ key: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: key]
        SecItemDelete(query as CFDictionary)
    }
}

// MARK: - On-device persistence (survives relaunch, restart and app updates)

struct Snapshot: Codable {
    var userId: String?
    var email: String = ""
    var wallet: Wallet?
    var transactions: [Transaction] = []
    var budgets: [Budget] = []
    var outbox: [OutboxOp] = []
    var apiCache: [String: Data] = [:]
    var lastSync: Date?
}

enum LocalStore {
    private static let queue = DispatchQueue(label: "localstore")

    private static var url: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FinanceTracker", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("snapshot.json")
    }

    static func load() -> Snapshot {
        guard let data = try? Data(contentsOf: url),
              let snap = try? JSONDecoder().decode(Snapshot.self, from: data) else { return Snapshot() }
        return snap
    }

    static func save(_ snapshot: Snapshot) {
        queue.async {
            guard let data = try? JSONEncoder().encode(snapshot) else { return }
            try? data.write(to: url, options: [.atomic, .completeFileProtection])
        }
    }

    static func delete() {
        queue.async { try? FileManager.default.removeItem(at: url) }
    }
}
