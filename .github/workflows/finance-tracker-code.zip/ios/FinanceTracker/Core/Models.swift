import SwiftUI

// MARK: - Money (exact decimal; the API sends/receives amounts as strings like "1250.50")

struct Money: Codable, Hashable, Comparable {
    var value: Decimal
    init(_ value: Decimal) { self.value = value }

    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        let posix = Locale(identifier: "en_US_POSIX")
        if let s = try? c.decode(String.self), let d = Decimal(string: s, locale: posix) {
            value = d
        } else if let n = try? c.decode(Double.self) {
            value = Decimal(string: String(n), locale: posix) ?? Decimal(n)
        } else {
            throw DecodingError.dataCorruptedError(in: c, debugDescription: "Invalid money value")
        }
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        try c.encode(wire)
    }

    /// Two-decimal, locale-independent string for the API.
    var wire: String {
        var source = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &source, 2, .plain)
        return Money.wireFormatter.string(from: NSDecimalNumber(decimal: rounded)) ?? "0.00"
    }

    private static let wireFormatter: NumberFormatter = {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.numberStyle = .decimal
        f.usesGroupingSeparator = false
        f.minimumFractionDigits = 2
        f.maximumFractionDigits = 2
        return f
    }()

    var double: Double { NSDecimalNumber(decimal: value).doubleValue }
    static func < (a: Money, b: Money) -> Bool { a.value < b.value }
    static let zero = Money(0)
}

// MARK: - Categories & lists

enum TxType: String, Codable, CaseIterable, Identifiable {
    case expense, income
    var id: String { rawValue }
}

enum Categories {
    static let expense = ["Food", "Shopping", "Transportation", "Entertainment", "Education",
                          "Technology", "Bills", "Subscriptions", "Healthcare", "Other"]
    static let income = ["Salary", "Allowance", "Gifts", "Freelance", "Other Income"]
    static let paymentMethods = ["Cash", "Card", "Bank Transfer", "Apple Pay", "Other"]

    static func all(for type: TxType) -> [String] { type == .expense ? expense : income }

    static func icon(_ c: String) -> String {
        switch c {
        case "Food": return "fork.knife"
        case "Shopping": return "bag.fill"
        case "Transportation": return "car.fill"
        case "Entertainment": return "popcorn.fill"
        case "Education": return "book.fill"
        case "Technology": return "laptopcomputer"
        case "Bills": return "doc.text.fill"
        case "Subscriptions": return "arrow.triangle.2.circlepath"
        case "Healthcare": return "cross.case.fill"
        case "Salary": return "banknote.fill"
        case "Allowance": return "wallet.pass.fill"
        case "Gifts": return "gift.fill"
        case "Freelance": return "laptopcomputer.and.iphone"
        default: return "circle.grid.2x2.fill"
        }
    }

    static func color(_ c: String) -> Color {
        switch c {
        case "Food": return .orange
        case "Shopping": return .pink
        case "Transportation": return .blue
        case "Entertainment": return .purple
        case "Education": return .indigo
        case "Technology": return .cyan
        case "Bills": return .red
        case "Subscriptions": return .teal
        case "Healthcare": return .mint
        case "Salary", "Allowance", "Gifts", "Freelance", "Other Income": return .green
        default: return .gray
        }
    }
}

enum Currencies {
    static let common: [(code: String, name: String)] = [
        ("AED", "UAE Dirham"), ("SAR", "Saudi Riyal"), ("QAR", "Qatari Riyal"), ("KWD", "Kuwaiti Dinar"),
        ("BHD", "Bahraini Dinar"), ("OMR", "Omani Rial"), ("USD", "US Dollar"), ("EUR", "Euro"),
        ("GBP", "British Pound"), ("INR", "Indian Rupee"), ("PKR", "Pakistani Rupee"),
        ("EGP", "Egyptian Pound"), ("JOD", "Jordanian Dinar"), ("TRY", "Turkish Lira"),
        ("CAD", "Canadian Dollar"), ("AUD", "Australian Dollar"), ("CHF", "Swiss Franc"),
        ("JPY", "Japanese Yen"), ("CNY", "Chinese Yuan"), ("SGD", "Singapore Dollar")
    ]
}

// MARK: - API models

struct Transaction: Codable, Identifiable, Hashable {
    var id: String
    var type: TxType
    var name: String
    var amount: Money
    var category: String
    var date: String            // yyyy-MM-dd
    var description: String
    var paymentMethod: String

    enum CodingKeys: String, CodingKey {
        case id, type, name, amount, category, date, description
        case paymentMethod = "payment_method"
    }

    var dateValue: Date { DateUtil.date(date) ?? .now }
}

struct Wallet: Codable, Hashable {
    var name: String
    var currency: String
    var startingBalance: Money
    enum CodingKeys: String, CodingKey { case name, currency; case startingBalance = "starting_balance" }
}

struct Balance: Codable, Hashable {
    var currency: String
    var startingBalance: Money
    var totalIncome: Money
    var totalExpenses: Money
    var balance: Money
    var transactionCount: Int
    var spentThisWeek: Money
    var spentThisMonth: Money
    enum CodingKeys: String, CodingKey {
        case currency
        case startingBalance = "starting_balance", totalIncome = "total_income"
        case totalExpenses = "total_expenses", balance
        case transactionCount = "transaction_count"
        case spentThisWeek = "spent_this_week", spentThisMonth = "spent_this_month"
    }
}

struct Budget: Codable, Hashable, Identifiable {
    var category: String
    var limit: Money
    var id: String { category }
}

struct BudgetList: Decodable { let items: [Budget] }
struct TransactionPage: Decodable { let items: [Transaction]; let total: Int }
struct UserInfo: Codable { let id: String; let email: String }

struct AuthResponse: Decodable {
    let user: UserInfo
    let wallet: Wallet
    let accessToken: String
    let refreshToken: String
    enum CodingKeys: String, CodingKey {
        case user, wallet
        case accessToken = "access_token", refreshToken = "refresh_token"
    }
}

struct SeriesPoint: Decodable, Identifiable { let bucket: String; let start: String; let amount: Money; var id: String { bucket } }
struct SpendingSeries: Decodable { let granularity: String; let total: Money; let points: [SeriesPoint] }

struct IEPoint: Decodable, Identifiable { let bucket: String; let start: String; let income: Money; let expenses: Money; var id: String { bucket } }
struct IncomeExpenseSeries: Decodable {
    let granularity: String
    let totalIncome: Money
    let totalExpenses: Money
    let points: [IEPoint]
    enum CodingKeys: String, CodingKey {
        case granularity, points
        case totalIncome = "total_income", totalExpenses = "total_expenses"
    }
}

struct CategoryShare: Decodable, Identifiable {
    let category: String
    let amount: Money
    let sharePercent: Double
    let count: Int
    var id: String { category }
    enum CodingKeys: String, CodingKey { case category, amount, count; case sharePercent = "share_percent" }
}
struct CategoryBreakdown: Decodable { let total: Money; let categories: [CategoryShare] }

struct BalancePoint: Decodable, Identifiable { let date: String; let balance: Money; var id: String { date } }
struct BalanceHistory: Decodable { let points: [BalancePoint] }

struct SummaryResponse: Decodable {
    let paragraph: String
    let sufficientData: Bool
    enum CodingKeys: String, CodingKey { case paragraph; case sufficientData = "sufficient_data" }
}

struct BudgetStatus: Decodable, Identifiable {
    let category: String
    let limit: Money
    let spent: Money
    let remaining: Money
    let percentUsed: Double
    let state: String           // ok | warning | exceeded
    var id: String { category }
    enum CodingKeys: String, CodingKey {
        case category, limit, spent, remaining, state
        case percentUsed = "percent_used"
    }
}
struct BudgetStatusResponse: Decodable { let month: String; let items: [BudgetStatus] }

// MARK: - Offline queue

enum OutboxOp: Codable, Hashable {
    case upsert(Transaction)
    case delete(String)

    var txId: String {
        switch self {
        case .upsert(let t): return t.id
        case .delete(let id): return id
        }
    }
}

struct Fetched<T> {
    let value: T
    let fromCache: Bool
}
