import XCTest
@testable import FinanceTracker

final class CoreTests: XCTestCase {
    func testMoneyDecodesStringsAndNumbersExactly() throws {
        struct Box: Decodable { let a: Money; let b: Money }
        let json = #"{"a":"1250.50","b":0.1}"#.data(using: .utf8)!
        let box = try JSONDecoder().decode(Box.self, from: json)
        XCTAssertEqual(box.a.wire, "1250.50")
        XCTAssertEqual(box.b.wire, "0.10")
    }

    func testMoneyEncodesTwoDecimalsWithoutGrouping() throws {
        let data = try JSONEncoder().encode(["v": Money(Decimal(string: "5000")!)])
        XCTAssertEqual(String(data: data, encoding: .utf8), #"{"v":"5000.00"}"#)
    }

    func testDecimalPlacesCheck() {
        XCTAssertTrue(Fmt.hasAtMostTwoDecimals(Decimal(string: "12.34")!))
        XCTAssertFalse(Fmt.hasAtMostTwoDecimals(Decimal(string: "12.345")!))
    }

    func testTransactionRoundTripUsesAPIKeys() throws {
        let tx = Transaction(id: "abc12345", type: .expense, name: "Lunch", amount: Money(12),
                             category: "Food", date: "2026-11-17", description: "", paymentMethod: "Card")
        let json = String(data: try JSONEncoder().encode(tx), encoding: .utf8)!
        XCTAssertTrue(json.contains("\"payment_method\":\"Card\""))
        XCTAssertTrue(json.contains("\"amount\":\"12.00\""))
    }

    @MainActor func testLocalBalanceFormula() {
        let app = AppState()
        app.wallet = Wallet(name: "W", currency: "AED", startingBalance: Money(5000))
        let today = DateUtil.today()
        app.transactions = [
            Transaction(id: "i1111111", type: .income, name: "Pay", amount: Money(1000), category: "Salary",
                        date: today, description: "", paymentMethod: "Other"),
            Transaction(id: "e1111111", type: .expense, name: "Shoes", amount: Money(1500), category: "Shopping",
                        date: today, description: "", paymentMethod: "Card")]
        let b = app.balanceInfo
        XCTAssertEqual(b.balance.wire, "4500.00")
        XCTAssertEqual(b.spentThisMonth.wire, "1500.00")
    }
}
