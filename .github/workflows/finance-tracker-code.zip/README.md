# Personal Finance Tracker: iOS app + API

## Honest status
| Part | State |
|---|---|
| **Backend API** (Flask + SQLite) | Built and **tested here**: 33 automated tests pass, plus a live HTTP smoke test (register, add expense, balance, summary, 401 without a token). |
| **iOS app** (SwiftUI) | **Written in full but NOT compiled or run.** The environment I built this in has no Xcode or Swift, so no `.ipa` exists and I have not seen it on a simulator. Expect to fix a few compile errors or layout issues on the first build. |
| Deployment files | Docker + Caddy included, not exercised. |

## Architecture
```
 iPhone (SwiftUI, iOS 17)                        Server
 ┌───────────────────────────────┐  HTTPS/JSON  ┌─────────────────────────────┐
 │ Views → AppState (@Observable) │◄────────────►│ Flask API (gunicorn)        │
 │  • on-device snapshot (JSON,   │  JWT access  │  • validation, auth         │
 │    file-protected)             │  + rotating  │  • balance / analytics /    │
 │  • outbox of unsent changes    │  refresh     │    summary calculations     │
 │  • Keychain: refresh token     │  token       │ SQLite (WAL), integer cents │
 └───────────────────────────────┘              │ behind Caddy (automatic TLS)│
                                                 └─────────────────────────────┘
```
**Technologies:** SwiftUI + Swift Charts (iOS 17), URLSession async/await, Keychain, NWPathMonitor, UserNotifications, Flask, SQLite, PyJWT, scrypt, Docker + Caddy.
I used Python/Flask rather than Swift on the server because it let me build and test the backend in this environment.

**How the app talks to the API.** Every request is `https://…/api/v1/...` with `Authorization: Bearer <15-minute JWT>`. On a 401 the client silently refreshes (the refresh token rotates each time, and a replayed one revokes all sessions) and retries once. No API secrets are in the app; the only secret (`FINANCE_JWT_SECRET`) lives on the server.

**How transactions are stored.** Table `transactions(user_id, id, type, name, amount_cents, category, date, description, payment_method, …)` with primary key `(user_id, id)`; every query filters by the authenticated user's id. Money is integer cents on the server and `Decimal` on the phone, never floating point. The phone keeps its own copy, so data survives relaunch, restart and app updates.

**Offline and sync.** Adding, editing or deleting updates the screen instantly and queues an operation. The queue is replayed with idempotent `PUT/DELETE /transactions/{id}` (client-generated UUIDs, so retries never duplicate), then the full server state is pulled back, so the server is the source of truth. Sync runs on launch, after each change, on pull-to-refresh and when connectivity returns. Analytics and the summary show the last loaded data with an "offline" note. Settings changes (wallet, budgets, restore) need a connection.

**How summaries are calculated** (`backend/analytics.py`, `build_summary`). Only from the user's stored rows. It reports starting and current balance, this month's spending, income and expense count, the top category and its share, the highest single expense, average spend per day (month-to-date ÷ days elapsed), and compares month-to-date spending with the *same number of days* last month (within ±5 % counts as "about the same"). It names the category with the biggest change, adds totals since you started and any budget warnings. With no transactions it says so; with fewer than 3 expenses it says more are needed; with no spending last month it says there is nothing to compare yet.

## Run the backend locally
```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
export FINANCE_JWT_SECRET=$(openssl rand -hex 32)     # required, at least 32 chars
export FINANCE_REQUIRE_HTTPS=0                         # local development only!
python app.py                                          # http://127.0.0.1:8000
python -m unittest discover                            # run the tests
```

## Deploy with HTTPS
```bash
export FINANCE_JWT_SECRET=$(openssl rand -hex 32) API_DOMAIN=api.yourdomain.com
docker compose up -d --build        # Caddy obtains a TLS certificate automatically
```
Point DNS for `API_DOMAIN` at the server first. In production the API refuses non-HTTPS requests. **Backups:** run `python backup_db.py /data/finance.db /backups` daily from cron (consistent online copy, keeps 14).

## Build the iOS app (Xcode 15+, macOS)
1. `brew install xcodegen && cd ios && xcodegen generate && open FinanceTracker.xcodeproj`
   (or create an iOS App named FinanceTracker in Xcode, minimum iOS 17, and drag the `FinanceTracker/` folder in).
2. Set your Team under *Signing & Capabilities*.
3. In `Core/Support.swift`, `Config.apiBaseURL`: Debug uses `http://localhost:8000` (simulator + the local server above; on a physical iPhone use your Mac's LAN address). Set the Release URL to your deployed `https://` API.
4. Run on a simulator and try: set up a wallet, add expenses and income, watch the dashboard, charts and summary update. Then switch on airplane mode, add a transaction, switch it off and watch it sync. Run the unit tests with ⌘U.

## Feature checklist
Setup (balance / currency / name) · dashboard (7 stats + summary) · expenses and income with edit/delete · analytics: spending over time (day/week/month/year), category donut, income vs expenses, balance history, 7D to All ranges · automatic summaries · history with search, category and date filters, sorting by date and amount · budgets with progress bars and local notifications at 80 % and over 100 % · settings (currency, starting balance, wallet name, CSV export, budgets, notifications, theme, backup/restore, sign out, delete account) · light and dark mode.

## Known gaps (not built)
- **Password reset and email verification** need an email provider. Recovery today means signing in on a new device (data re-syncs) or restoring a backup file.
- **Push notifications (APNs).** Budget alerts are local and are only evaluated while the app is running or syncing.
- Settings changes can't be made offline, and conflicts are resolved as "last write wins" per transaction.
- No Face ID lock, certificate pinning, app icon, localisation or iPad layout. SQLite on one server suits a personal or small-scale app; use Postgres beyond that.
- Rate limiting covers sign-in only; add a WAF or rate limiter in front for production.
- Registration returns 409 for an existing email, which reveals that the email is registered (a common trade-off).
