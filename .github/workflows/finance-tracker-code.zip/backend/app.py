"""Personal Finance Tracker API. Run with: gunicorn "app:create_app()" """
import base64
import csv
import hashlib
import hmac
import io
import json
import os
import secrets
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import Blueprint, Flask, Response, current_app, g, jsonify, request
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix

import analytics
from analytics import fmt
from db import close_db, get_db, init_db
from validation import (ApiError, EXPENSE_CATEGORIES, bad, parse_money, validate_email, validate_id,
                        validate_password, validate_transaction, validate_wallet)

api = Blueprint("api", __name__, url_prefix="/api/v1")


# ------------------------------------------------------------------ helpers
def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def json_body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise bad("Request body must be a JSON object")
    return data


def client_today():
    """The client's local date (X-Client-Date), so 'today/this week/this month' match the user's timezone.
    Accepted only within +/-1 day of UTC today, which covers every real timezone."""
    utc_today = datetime.now(timezone.utc).date()
    h = request.headers.get("X-Client-Date", "")
    try:
        d = date.fromisoformat(h) if len(h) == 10 else None
    except ValueError:
        d = None
    return d if d and abs((d - utc_today).days) <= 1 else utc_today


def hash_password(pw):
    salt = os.urandom(16)
    n, r, p = 2 ** 15, 8, 1
    h = hashlib.scrypt(pw.encode(), salt=salt, n=n, r=r, p=p, dklen=32, maxmem=128 * 1024 * 1024)
    return f"scrypt${n}${r}${p}${base64.b64encode(salt).decode()}${base64.b64encode(h).decode()}"


def verify_password(pw, stored):
    try:
        _, n, r, p, salt, expected = stored.split("$")
        h = hashlib.scrypt(pw.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p),
                           dklen=32, maxmem=128 * 1024 * 1024)
        return hmac.compare_digest(h, base64.b64decode(expected))
    except Exception:
        return False


_DUMMY_HASH = None


def dummy_verify(pw):
    """Burn the same CPU for unknown emails so response time doesn't reveal which emails exist."""
    global _DUMMY_HASH
    _DUMMY_HASH = _DUMMY_HASH or hash_password("dummy-password")
    verify_password(pw, _DUMMY_HASH)


def issue_tokens(db, user_id):
    cfg = current_app.config
    now = int(time.time())
    access = jwt.encode({"sub": user_id, "typ": "access", "iat": now, "exp": now + cfg["ACCESS_TTL"],
                         "jti": uuid.uuid4().hex}, cfg["JWT_SECRET"], algorithm="HS256")
    refresh = secrets.token_urlsafe(48)
    exp = (datetime.now(timezone.utc) + timedelta(seconds=cfg["REFRESH_TTL"])).isoformat(timespec="seconds")
    db.execute("INSERT INTO refresh_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)",
               (hashlib.sha256(refresh.encode()).hexdigest(), user_id, exp))
    return {"access_token": access, "refresh_token": refresh, "token_type": "Bearer",
            "expires_in": cfg["ACCESS_TTL"]}


def auth_required(fn):
    @wraps(fn)
    def wrapper(*a, **k):
        h = request.headers.get("Authorization", "")
        if not h.startswith("Bearer "):
            raise ApiError(401, "unauthorized", "Missing bearer token")
        try:
            claims = jwt.decode(h[7:], current_app.config["JWT_SECRET"], algorithms=["HS256"],
                                options={"require": ["exp", "sub", "iat"]})
        except jwt.PyJWTError:
            raise ApiError(401, "unauthorized", "Invalid or expired token")
        if claims.get("typ") != "access" or not get_db().execute(
                "SELECT 1 FROM users WHERE id=?", (claims["sub"],)).fetchone():
            raise ApiError(401, "unauthorized", "Invalid or expired token")
        g.user_id = claims["sub"]
        return fn(*a, **k)
    return wrapper


def wallet_row(db, uid):
    return db.execute("SELECT * FROM wallets WHERE user_id=?", (uid,)).fetchone()


def wallet_json(w):
    return {"name": w["name"], "currency": w["currency"], "starting_balance": fmt(w["starting_balance_cents"])}


def tx_json(r):
    return {"id": r["id"], "type": r["type"], "name": r["name"], "amount": fmt(r["amount_cents"]),
            "category": r["category"], "date": r["date"], "description": r["description"],
            "payment_method": r["payment_method"], "created_at": r["created_at"],
            "updated_at": r["updated_at"]}


def upsert_tx(db, uid, tx_id, v):
    now = utcnow()
    existed = db.execute("SELECT 1 FROM transactions WHERE user_id=? AND id=?", (uid, tx_id)).fetchone()
    db.execute(
        """INSERT INTO transactions(id,user_id,type,name,amount_cents,category,date,description,
                                    payment_method,created_at,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(user_id,id) DO UPDATE SET type=excluded.type, name=excluded.name,
             amount_cents=excluded.amount_cents, category=excluded.category, date=excluded.date,
             description=excluded.description, payment_method=excluded.payment_method,
             updated_at=excluded.updated_at""",
        (tx_id, uid, v["type"], v["name"], v["amount_cents"], v["category"], v["date"], v["description"],
         v["payment_method"], now, now))
    return existed is not None


def load_rows(db, uid, start=None, end=None):
    q, args = "SELECT name,type,amount_cents,category,date FROM transactions WHERE user_id=?", [uid]
    if start:
        q += " AND date>=?"
        args.append(start.isoformat())
    if end:
        q += " AND date<=?"
        args.append(end.isoformat())
    return db.execute(q, args).fetchall()


def first_tx_date(db, uid):
    r = db.execute("SELECT MIN(date) m FROM transactions WHERE user_id=?", (uid,)).fetchone()["m"]
    return date.fromisoformat(r) if r else None


def parse_range():
    key = request.args.get("range", "30d")
    if key != "all" and key not in analytics.RANGE_DAYS:
        raise bad("range must be one of: 7d, 30d, 3m, 6m, 1y, all", "range")
    return key


def parse_granularity(start, end):
    gran = request.args.get("granularity") or analytics.default_granularity(start, end)
    if gran not in analytics.GRANULARITIES:
        raise bad("granularity must be one of: day, week, month, year", "granularity")
    if len(analytics.make_buckets(start, end, gran)) > analytics.MAX_BUCKETS:
        raise bad("granularity is too fine for this range; choose a coarser one", "granularity")
    return gran


# ------------------------------------------------------------------ auth
@api.post("/auth/register")
def register():
    db, body = get_db(), json_body()
    email, pw = validate_email(body.get("email")), validate_password(body.get("password"))
    wallet = validate_wallet(body.get("wallet"))
    if db.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
        raise ApiError(409, "email_taken", "An account with this email already exists")
    uid, now = str(uuid.uuid4()), utcnow()
    db.execute("INSERT INTO users(id,email,password_hash,created_at) VALUES(?,?,?,?)",
               (uid, email, hash_password(pw), now))
    db.execute("INSERT INTO wallets(user_id,name,currency,starting_balance_cents,created_at,updated_at) "
               "VALUES(?,?,?,?,?,?)",
               (uid, wallet["name"], wallet["currency"], wallet["starting_balance_cents"], now, now))
    tokens = issue_tokens(db, uid)
    db.commit()
    return jsonify({"user": {"id": uid, "email": email}, "wallet": wallet_json(wallet_row(db, uid)),
                    **tokens}), 201


@api.post("/auth/login")
def login():
    db, body = get_db(), json_body()
    email, pw = body.get("email"), body.get("password")
    if not isinstance(email, str) or not isinstance(pw, str):
        raise bad("email and password are required")
    email = email.strip().lower()
    cfg, key, now = current_app.config, f"{request.remote_addr}|{email}", time.time()
    db.execute("DELETE FROM login_attempts WHERE at<?", (now - cfg["LOGIN_WINDOW"],))
    n = db.execute("SELECT COUNT(*) c FROM login_attempts WHERE key=?", (key,)).fetchone()["c"]
    if n >= cfg["LOGIN_MAX_ATTEMPTS"]:
        db.commit()
        raise ApiError(429, "too_many_attempts", "Too many failed sign-in attempts. Try again later.")
    user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user:
        dummy_verify(pw)
    if not user or not verify_password(pw, user["password_hash"]):
        db.execute("INSERT INTO login_attempts(key,at) VALUES(?,?)", (key, now))
        db.commit()
        raise ApiError(401, "invalid_credentials", "Invalid email or password")
    db.execute("DELETE FROM login_attempts WHERE key=?", (key,))
    tokens = issue_tokens(db, user["id"])
    db.commit()
    return jsonify({"user": {"id": user["id"], "email": user["email"]},
                    "wallet": wallet_json(wallet_row(db, user["id"])), **tokens})


@api.post("/auth/refresh")
def refresh():
    db, body = get_db(), json_body()
    token = body.get("refresh_token")
    if not isinstance(token, str):
        raise bad("refresh_token is required", "refresh_token")
    h = hashlib.sha256(token.encode()).hexdigest()
    row = db.execute("SELECT * FROM refresh_tokens WHERE token_hash=?", (h,)).fetchone()
    if not row:
        raise ApiError(401, "invalid_refresh_token", "Invalid refresh token")
    if row["revoked"]:  # a rotated token was replayed: assume theft and sign out every session
        db.execute("UPDATE refresh_tokens SET revoked=1 WHERE user_id=?", (row["user_id"],))
        db.commit()
        raise ApiError(401, "invalid_refresh_token", "Invalid refresh token")
    if row["expires_at"] < utcnow():
        raise ApiError(401, "invalid_refresh_token", "Refresh token expired")
    db.execute("UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?", (h,))
    tokens = issue_tokens(db, row["user_id"])
    db.commit()
    return jsonify(tokens)


@api.post("/auth/logout")
def logout():
    db, token = get_db(), json_body().get("refresh_token")
    if isinstance(token, str):
        db.execute("UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?",
                   (hashlib.sha256(token.encode()).hexdigest(),))
        db.commit()
    return "", 204


@api.get("/me")
@auth_required
def me():
    u = get_db().execute("SELECT id,email,created_at FROM users WHERE id=?", (g.user_id,)).fetchone()
    return jsonify(dict(u))


@api.delete("/me")
@auth_required
def delete_me():
    db = get_db()
    u = db.execute("SELECT password_hash FROM users WHERE id=?", (g.user_id,)).fetchone()
    pw = json_body().get("password")
    if not isinstance(pw, str) or not verify_password(pw, u["password_hash"]):
        raise ApiError(403, "invalid_password", "Password is incorrect")
    db.execute("DELETE FROM users WHERE id=?", (g.user_id,))  # cascades to wallet, transactions, budgets, tokens
    db.commit()
    return "", 204


# ------------------------------------------------------------------ wallet & balance
@api.get("/wallet")
@auth_required
def get_wallet():
    return jsonify(wallet_json(wallet_row(get_db(), g.user_id)))


@api.put("/wallet")
@auth_required
def put_wallet():
    """Edits wallet settings only; transactions are never touched."""
    db, v = get_db(), validate_wallet(json_body(), partial=True)
    sets = ", ".join(f"{k}=?" for k in v)
    db.execute(f"UPDATE wallets SET {sets}, updated_at=? WHERE user_id=?", (*v.values(), utcnow(), g.user_id))
    db.commit()
    return jsonify(wallet_json(wallet_row(db, g.user_id)))


@api.get("/balance")
@auth_required
def balance():
    db, uid, today = get_db(), g.user_id, client_today()
    w = wallet_row(db, uid)
    r = db.execute(
        """SELECT COALESCE(SUM(CASE WHEN type='income'  THEN amount_cents END),0) inc,
                  COALESCE(SUM(CASE WHEN type='expense' THEN amount_cents END),0) exp,
                  COUNT(*) n,
                  COALESCE(SUM(CASE WHEN type='expense' AND date>=? THEN amount_cents END),0) wk,
                  COALESCE(SUM(CASE WHEN type='expense' AND date>=? THEN amount_cents END),0) mo
           FROM transactions WHERE user_id=?""",
        ((today - timedelta(days=today.weekday())).isoformat(), today.replace(day=1).isoformat(), uid)).fetchone()
    start = w["starting_balance_cents"]
    return jsonify({"currency": w["currency"], "starting_balance": fmt(start),
                    "total_income": fmt(r["inc"]), "total_expenses": fmt(r["exp"]),
                    "balance": fmt(start + r["inc"] - r["exp"]), "transaction_count": r["n"],
                    "spent_this_week": fmt(r["wk"]), "spent_this_month": fmt(r["mo"]),
                    "as_of": today.isoformat()})


# ------------------------------------------------------------------ transactions
SORTS = {"newest": "date DESC, created_at DESC, id", "oldest": "date ASC, created_at ASC, id",
         "highest": "amount_cents DESC, date DESC, id", "lowest": "amount_cents ASC, date DESC, id"}


@api.get("/transactions")
@auth_required
def list_transactions():
    db, uid, a = get_db(), g.user_id, request.args
    where, args = ["user_id=?"], [uid]
    if a.get("type"):
        if a["type"] not in ("expense", "income"):
            raise bad("type must be 'expense' or 'income'", "type")
        where.append("type=?")
        args.append(a["type"])
    if a.get("category"):
        where.append("category=?")
        args.append(a["category"])
    for name, op in (("from", ">="), ("to", "<=")):
        if a.get(name):
            where.append(f"date{op}?")
            args.append(validate_date_arg(a[name], name))
    if a.get("q"):
        like = "%" + a["q"].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(name LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\')")
        args += [like] * 3
    sort = a.get("sort", "newest")
    if sort not in SORTS:
        raise bad("sort must be one of: newest, oldest, highest, lowest", "sort")
    try:
        limit, offset = int(a.get("limit", 100)), int(a.get("offset", 0))
    except ValueError:
        raise bad("limit and offset must be integers")
    if not (1 <= limit <= 500) or offset < 0:
        raise bad("limit must be 1-500 and offset >= 0")
    w = " AND ".join(where)
    total = db.execute(f"SELECT COUNT(*) c FROM transactions WHERE {w}", args).fetchone()["c"]
    rows = db.execute(f"SELECT * FROM transactions WHERE {w} ORDER BY {SORTS[sort]} LIMIT ? OFFSET ?",
                      (*args, limit, offset)).fetchall()
    return jsonify({"items": [tx_json(r) for r in rows], "total": total, "limit": limit, "offset": offset})


def validate_date_arg(value, name):
    from validation import parse_date
    return parse_date(value, name, client_today()).isoformat()


@api.post("/transactions")
@auth_required
def create_transaction():
    db, body = get_db(), json_body()
    v = validate_transaction(body, client_today())
    tx_id = validate_id(body["id"]) if "id" in body else str(uuid.uuid4())
    if db.execute("SELECT 1 FROM transactions WHERE user_id=? AND id=?", (g.user_id, tx_id)).fetchone():
        raise ApiError(409, "id_exists", "A transaction with this id already exists; use PUT to update it")
    upsert_tx(db, g.user_id, tx_id, v)
    db.commit()
    return jsonify(tx_json(db.execute("SELECT * FROM transactions WHERE user_id=? AND id=?",
                                      (g.user_id, tx_id)).fetchone())), 201


@api.get("/transactions/<tx_id>")
@auth_required
def get_transaction(tx_id):
    r = get_db().execute("SELECT * FROM transactions WHERE user_id=? AND id=?", (g.user_id, tx_id)).fetchone()
    if not r:
        raise ApiError(404, "not_found", "Transaction not found")
    return jsonify(tx_json(r))


@api.put("/transactions/<tx_id>")
@auth_required
def put_transaction(tx_id):
    """Idempotent upsert: lets offline clients replay queued changes safely."""
    db = get_db()
    validate_id(tx_id)
    v = validate_transaction(json_body(), client_today())
    existed = upsert_tx(db, g.user_id, tx_id, v)
    db.commit()
    r = db.execute("SELECT * FROM transactions WHERE user_id=? AND id=?", (g.user_id, tx_id)).fetchone()
    return jsonify(tx_json(r)), (200 if existed else 201)


@api.delete("/transactions/<tx_id>")
@auth_required
def delete_transaction(tx_id):
    """Idempotent: deleting something already gone still succeeds."""
    db = get_db()
    db.execute("DELETE FROM transactions WHERE user_id=? AND id=?", (g.user_id, tx_id))
    db.commit()
    return "", 204


# ------------------------------------------------------------------ analytics & summary
@api.get("/analytics/spending-over-time")
@auth_required
def spending_over_time():
    db, uid, today = get_db(), g.user_id, client_today()
    key = parse_range()
    start, end = analytics.range_bounds(key, today, first_tx_date(db, uid))
    gran = parse_granularity(start, end)
    pts = analytics.time_series(load_rows(db, uid, start, end), start, end, gran)
    return jsonify({"range": key, "granularity": gran, "start": start.isoformat(), "end": end.isoformat(),
                    "total": fmt(sum(p["expenses_cents"] for p in pts)),
                    "points": [{"bucket": p["bucket"], "start": p["start"], "amount": fmt(p["expenses_cents"])}
                               for p in pts]})


@api.get("/analytics/income-vs-expenses")
@auth_required
def income_vs_expenses():
    db, uid, today = get_db(), g.user_id, client_today()
    key = parse_range()
    start, end = analytics.range_bounds(key, today, first_tx_date(db, uid))
    gran = parse_granularity(start, end)
    pts = analytics.time_series(load_rows(db, uid, start, end), start, end, gran)
    return jsonify({"range": key, "granularity": gran, "start": start.isoformat(), "end": end.isoformat(),
                    "total_income": fmt(sum(p["income_cents"] for p in pts)),
                    "total_expenses": fmt(sum(p["expenses_cents"] for p in pts)),
                    "points": [{"bucket": p["bucket"], "start": p["start"], "income": fmt(p["income_cents"]),
                                "expenses": fmt(p["expenses_cents"])} for p in pts]})


@api.get("/analytics/by-category")
@auth_required
def spending_by_category():
    db, uid, today = get_db(), g.user_id, client_today()
    key = parse_range()
    start, end = analytics.range_bounds(key, today, first_tx_date(db, uid))
    items, total = analytics.by_category(load_rows(db, uid, start, end), start, end)
    return jsonify({"range": key, "start": start.isoformat(), "end": end.isoformat(), "total": fmt(total),
                    "categories": [{"category": i["category"], "amount": fmt(i["amount_cents"]),
                                    "share_percent": i["share_percent"], "count": i["count"]} for i in items]})


@api.get("/analytics/balance-history")
@auth_required
def balance_history_route():
    db, uid, today = get_db(), g.user_id, client_today()
    key = parse_range()
    start, end = analytics.range_bounds(key, today, first_tx_date(db, uid))
    pts = analytics.balance_history(load_rows(db, uid, None, end), wallet_row(db, uid)["starting_balance_cents"],
                                    start, end)
    return jsonify({"range": key, "start": start.isoformat(), "end": end.isoformat(),
                    "points": [{"date": p["date"], "balance": fmt(p["balance_cents"])} for p in pts]})


def budget_items(db, uid, today):
    budgets = db.execute("SELECT category,limit_cents FROM budgets WHERE user_id=? ORDER BY category",
                         (uid,)).fetchall()
    return analytics.budget_status(budgets, load_rows(db, uid, today.replace(day=1), today), today)


@api.get("/summary")
@auth_required
def summary():
    db, uid, today = get_db(), g.user_id, client_today()
    result = analytics.build_summary(load_rows(db, uid), wallet_row(db, uid), today, budget_items(db, uid, today))
    result["generated_at"] = utcnow()
    return jsonify(result)


# ------------------------------------------------------------------ budgets
def budget_json(items):
    return [{"category": i["category"], "limit": fmt(i["limit_cents"])} for i in items]


@api.get("/budgets")
@auth_required
def list_budgets():
    rows = get_db().execute("SELECT category,limit_cents FROM budgets WHERE user_id=? ORDER BY category",
                            (g.user_id,)).fetchall()
    return jsonify({"items": budget_json(rows)})


@api.put("/budgets/<category>")
@auth_required
def put_budget(category):
    if category not in EXPENSE_CATEGORIES:
        raise bad(f"category must be one of: {', '.join(EXPENSE_CATEGORIES)}", "category")
    cents = parse_money(json_body().get("limit"), "limit")
    if cents <= 0:
        raise bad("limit must be greater than 0", "limit")
    db = get_db()
    db.execute("INSERT INTO budgets(user_id,category,limit_cents,updated_at) VALUES(?,?,?,?) "
               "ON CONFLICT(user_id,category) DO UPDATE SET limit_cents=excluded.limit_cents, "
               "updated_at=excluded.updated_at", (g.user_id, category, cents, utcnow()))
    db.commit()
    return jsonify({"category": category, "limit": fmt(cents)})


@api.delete("/budgets/<category>")
@auth_required
def delete_budget(category):
    db = get_db()
    db.execute("DELETE FROM budgets WHERE user_id=? AND category=?", (g.user_id, category))
    db.commit()
    return "", 204


@api.get("/budgets/status")
@auth_required
def budgets_status():
    today = client_today()
    items = budget_items(get_db(), g.user_id, today)
    return jsonify({"month": today.strftime("%Y-%m"), "items": [
        {"category": i["category"], "limit": fmt(i["limit_cents"]), "spent": fmt(i["spent_cents"]),
         "remaining": fmt(i["remaining_cents"]), "percent_used": i["percent_used"], "state": i["state"]}
        for i in items]})


# ------------------------------------------------------------------ export / backup / restore
def csv_safe(v):
    s = str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s  # blocks spreadsheet formula injection


@api.get("/export/csv")
@auth_required
def export_csv():
    db = get_db()
    cur = wallet_row(db, g.user_id)["currency"]
    out = io.StringIO()
    wr = csv.writer(out)
    wr.writerow(["id", "date", "type", "name", "category", "amount", "currency", "payment_method", "description"])
    for r in db.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY date DESC, created_at DESC",
                        (g.user_id,)):
        wr.writerow([r["id"], r["date"], r["type"], csv_safe(r["name"]), csv_safe(r["category"]),
                     fmt(r["amount_cents"]), cur, r["payment_method"], csv_safe(r["description"])])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=transactions.csv"})


@api.get("/backup")
@auth_required
def backup():
    db, uid = get_db(), g.user_id
    rows = db.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY date, created_at", (uid,)).fetchall()
    budgets = db.execute("SELECT category,limit_cents FROM budgets WHERE user_id=?", (uid,)).fetchall()
    payload = {"version": 1, "exported_at": utcnow(), "wallet": wallet_json(wallet_row(db, uid)),
               "transactions": [{k: tx_json(r)[k] for k in
                                 ("id", "type", "name", "amount", "category", "date", "description",
                                  "payment_method")} for r in rows],
               "budgets": budget_json(budgets)}
    return Response(json.dumps(payload, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=finance-backup.json"})


@api.post("/restore")
@auth_required
def restore():
    """Restore a backup file. mode=merge adds/updates; mode=replace wipes transactions & budgets first."""
    db, body, today = get_db(), json_body(), client_today()
    mode, b = body.get("mode"), body.get("backup")
    if mode not in ("merge", "replace"):
        raise bad("mode must be 'merge' or 'replace'", "mode")
    if not isinstance(b, dict) or b.get("version") != 1:
        raise bad("backup must be a version 1 backup object", "backup")
    txs, budgets = b.get("transactions", []), b.get("budgets", [])
    if not isinstance(txs, list) or not isinstance(budgets, list) or len(txs) > 50000:
        raise bad("backup contains invalid or too many transactions", "backup")
    parsed = [(validate_id(t.get("id") if isinstance(t, dict) else None), validate_transaction(t, today))
              for t in txs]
    parsed_budgets = []
    for x in budgets:
        if not isinstance(x, dict) or x.get("category") not in EXPENSE_CATEGORIES:
            raise bad("backup contains an invalid budget", "backup")
        cents = parse_money(x.get("limit"), "limit")
        if cents <= 0:
            raise bad("backup contains an invalid budget", "backup")
        parsed_budgets.append((x["category"], cents))
    wallet = validate_wallet(b["wallet"]) if mode == "replace" and "wallet" in b else None
    uid = g.user_id
    if mode == "replace":
        db.execute("DELETE FROM transactions WHERE user_id=?", (uid,))
        db.execute("DELETE FROM budgets WHERE user_id=?", (uid,))
        if wallet:
            db.execute("UPDATE wallets SET name=?, currency=?, starting_balance_cents=?, updated_at=? "
                       "WHERE user_id=?", (wallet["name"], wallet["currency"], wallet["starting_balance_cents"],
                                           utcnow(), uid))
    for tx_id, v in parsed:
        upsert_tx(db, uid, tx_id, v)
    for cat, cents in parsed_budgets:
        db.execute("INSERT INTO budgets(user_id,category,limit_cents,updated_at) VALUES(?,?,?,?) "
                   "ON CONFLICT(user_id,category) DO UPDATE SET limit_cents=excluded.limit_cents",
                   (uid, cat, cents, utcnow()))
    db.commit()
    return jsonify({"restored_transactions": len(parsed), "restored_budgets": len(parsed_budgets)})


# ------------------------------------------------------------------ app factory
def create_app(config=None):
    app = Flask(__name__)
    cfg = {
        "DB_PATH": os.environ.get("FINANCE_DB_PATH", "finance.db"),
        "JWT_SECRET": os.environ.get("FINANCE_JWT_SECRET", ""),
        "REQUIRE_HTTPS": os.environ.get("FINANCE_REQUIRE_HTTPS", "1") == "1",
        "BEHIND_PROXY": os.environ.get("FINANCE_BEHIND_PROXY", "0") == "1",
        "ACCESS_TTL": 15 * 60, "REFRESH_TTL": 60 * 24 * 3600,
        "LOGIN_MAX_ATTEMPTS": 10, "LOGIN_WINDOW": 15 * 60,
        "MAX_CONTENT_LENGTH": 10 * 1024 * 1024,
    }
    cfg.update(config or {})
    if len(cfg["JWT_SECRET"]) < 32:
        raise RuntimeError("Set FINANCE_JWT_SECRET to a random string of at least 32 characters "
                           "(e.g. `openssl rand -hex 32`).")
    app.config.update(cfg)
    if cfg["BEHIND_PROXY"]:  # trust X-Forwarded-* from exactly one reverse proxy (Caddy/nginx)
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)
    init_db(app)
    app.teardown_appcontext(close_db)
    app.register_blueprint(api)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.before_request
    def enforce_https():
        if app.config["REQUIRE_HTTPS"] and not request.is_secure and request.path != "/health":
            raise ApiError(403, "https_required", "This API is only available over HTTPS")

    @app.after_request
    def security_headers(resp):
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return resp

    @app.errorhandler(ApiError)
    def on_api_error(e):
        body = {"error": {"code": e.code, "message": e.message}}
        if e.details:
            body["error"]["details"] = e.details
        return jsonify(body), e.status

    @app.errorhandler(HTTPException)
    def on_http_error(e):
        return jsonify({"error": {"code": e.name.lower().replace(" ", "_"), "message": e.description}}), e.code

    @app.errorhandler(Exception)
    def on_error(e):
        app.logger.exception("Unhandled error")
        return jsonify({"error": {"code": "internal_error", "message": "Something went wrong"}}), 500

    return app


if __name__ == "__main__":  # local development only
    create_app().run(host="127.0.0.1", port=8000)
