"""Consistent online backup of the SQLite database (safe while the API is running).
Usage: python backup_db.py /path/to/db /path/to/backup_dir   (run daily from cron; keeps 14 copies)"""
import sqlite3, sys, time
from pathlib import Path

src, dest_dir = Path(sys.argv[1]), Path(sys.argv[2])
dest_dir.mkdir(parents=True, exist_ok=True)
dest = dest_dir / f"finance-{time.strftime('%Y%m%d-%H%M%S')}.db"
with sqlite3.connect(src) as s, sqlite3.connect(dest) as d:
    s.backup(d)
dest.chmod(0o600)
for old in sorted(dest_dir.glob("finance-*.db"))[:-14]:
    old.unlink()
print("backup written:", dest)
