"""Pure functions that turn transaction rows into analytics series and the written summary.

Rows are mappings with: type, amount_cents, category, date (ISO string), and name (for summaries).
Nothing here invents data: every number in the summary paragraph comes from the rows passed in.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

RANGE_DAYS = {"7d": 7, "30d": 30, "3m": 90, "6m": 180, "1y": 365}
GRANULARITIES = ("day", "week", "month", "year")
MAX_BUCKETS = 1500
WARN_PERCENT = 80.0


def fmt(cents):
    return f"{Decimal(cents) / 100:.2f}"


def money(cents, cur):
    d = Decimal(cents) / 100
    return f"{d:,.0f} {cur}" if cents % 100 == 0 else f"{d:,.2f} {cur}"


# ---------------------------------------------------------------- ranges & buckets
def range_bounds(key, today, first_date):
    if key == "all":
        return min(first_date or today, today), today
    return today - timedelta(days=RANGE_DAYS[key] - 1), today


def default_granularity(start, end):
    span = (end - start).days + 1
    if span <= 62:
        return "day"
    if span <= 190:
        return "week"
    if span <= 1100:
        return "month"
    return "year"


def bucket_start(d, gran):
    if gran == "day":
        return d
    if gran == "week":
        return d - timedelta(days=d.weekday())  # ISO weeks start on Monday
    if gran == "month":
        return d.replace(day=1)
    return d.replace(month=1, day=1)


def bucket_label(b, gran):
    if gran in ("day", "week"):
        return b.isoformat()
    return b.strftime("%Y-%m") if gran == "month" else b.strftime("%Y")


def next_bucket(b, gran):
    if gran == "day":
        return b + timedelta(days=1)
    if gran == "week":
        return b + timedelta(days=7)
    if gran == "month":
        return date(b.year + (b.month == 12), b.month % 12 + 1, 1)
    return date(b.year + 1, 1, 1)


def make_buckets(start, end, gran):
    b, out = bucket_start(start, gran), []
    while b <= end:
        out.append(b)
        b = next_bucket(b, gran)
    return out


def time_series(rows, start, end, gran):
    buckets = make_buckets(start, end, gran)
    idx = {b: i for i, b in enumerate(buckets)}
    exp, inc = [0] * len(buckets), [0] * len(buckets)
    for r in rows:
        d = date.fromisoformat(r["date"])
        if d < start or d > end:
            continue
        i = idx[bucket_start(d, gran)]
        if r["type"] == "expense":
            exp[i] += r["amount_cents"]
        else:
            inc[i] += r["amount_cents"]
    return [{"bucket": bucket_label(b, gran), "start": b.isoformat(),
             "expenses_cents": exp[i], "income_cents": inc[i]} for i, b in enumerate(buckets)]


def by_category(rows, start, end):
    totals, counts = defaultdict(int), defaultdict(int)
    for r in rows:
        if r["type"] == "expense" and start.isoformat() <= r["date"] <= end.isoformat():
            totals[r["category"]] += r["amount_cents"]
            counts[r["category"]] += 1
    grand = sum(totals.values())
    items = [{"category": c, "amount_cents": v, "count": counts[c],
              "share_percent": round(v * 100 / grand, 1) if grand else 0.0}
             for c, v in sorted(totals.items(), key=lambda kv: (-kv[1], kv[0]))]
    return items, grand


def balance_history(rows, starting_cents, start, end):
    """End-of-day balance for each day in [start, end]; transactions before `start` are included."""
    deltas = defaultdict(int)
    running = starting_cents
    for r in rows:
        signed = r["amount_cents"] if r["type"] == "income" else -r["amount_cents"]
        if r["date"] < start.isoformat():
            running += signed
        elif r["date"] <= end.isoformat():
            deltas[r["date"]] += signed
    points, d = [], start
    while d <= end:
        running += deltas.get(d.isoformat(), 0)
        points.append({"date": d.isoformat(), "balance_cents": running})
        d += timedelta(days=1)
    if len(points) > 200:  # keep payloads small on long ranges; always keep the final point
        step = -(-len(points) // 150)
        points = points[::step] + ([points[-1]] if (len(points) - 1) % step else [])
    return points


# ---------------------------------------------------------------- budgets
def budget_status(budgets, expense_rows, today):
    ms = today.replace(day=1).isoformat()
    spent = defaultdict(int)
    for r in expense_rows:
        if r["type"] == "expense" and ms <= r["date"] <= today.isoformat():
            spent[r["category"]] += r["amount_cents"]
    items = []
    for b in budgets:
        s, lim = spent.get(b["category"], 0), b["limit_cents"]
        pct = round(s * 100 / lim, 1)
        state = "exceeded" if s > lim else ("warning" if pct >= WARN_PERCENT else "ok")
        items.append({"category": b["category"], "limit_cents": lim, "spent_cents": s,
                      "remaining_cents": lim - s, "percent_used": pct, "state": state})
    return items


# ---------------------------------------------------------------- written summary
def _plural(n, word):
    return f"{n} {word}{'' if n == 1 else 's'}"


def _cat_totals(rows):
    t = defaultdict(int)
    for r in rows:
        t[r["category"]] += r["amount_cents"]
    return t


def build_summary(rows, wallet, today, budget_items):
    cur, start_c = wallet["currency"], wallet["starting_balance_cents"]
    exp_rows = [r for r in rows if r["type"] == "expense"]
    inc_rows = [r for r in rows if r["type"] == "income"]
    total_exp = sum(r["amount_cents"] for r in exp_rows)
    total_inc = sum(r["amount_cents"] for r in inc_rows)
    balance = start_c + total_inc - total_exp

    facts = {"currency": cur, "starting_balance": fmt(start_c), "current_balance": fmt(balance),
             "total_income": fmt(total_inc), "total_expenses": fmt(total_exp),
             "transaction_count": len(rows)}

    if not rows:
        text = (f"You haven't recorded any transactions yet. Your starting balance is "
                f"{money(start_c, cur)}, which is also your current available balance. "
                f"Add your first expense or income to start seeing insights here.")
        return {"paragraph": text, "sufficient_data": False, "facts": facts}

    ms, elapsed = today.replace(day=1), today.day
    pm_end = ms - timedelta(days=1)
    pm_start = pm_end.replace(day=1)
    pm_cmp_end = pm_start + timedelta(days=min(elapsed, pm_end.day) - 1)

    def within(r, a, b):
        return a.isoformat() <= r["date"] <= b.isoformat()

    m_exp = [r for r in exp_rows if within(r, ms, today)]
    p_exp = [r for r in exp_rows if within(r, pm_start, pm_cmp_end)]
    m_inc_total = sum(r["amount_cents"] for r in inc_rows if within(r, ms, today))
    m_spent = sum(r["amount_cents"] for r in m_exp)
    p_spent = sum(r["amount_cents"] for r in p_exp)
    avg_daily = round(m_spent / elapsed)
    month_name = today.strftime("%B")

    s = [f"Your starting balance was {money(start_c, cur)}."]
    if m_exp or m_inc_total:
        s.append(f"So far in {month_name} you have spent {money(m_spent, cur)} across "
                 f"{_plural(len(m_exp), 'expense')} and received {money(m_inc_total, cur)} in income.")
    else:
        s.append(f"You haven't recorded any spending or income so far in {month_name}.")
    s.append(f"Your current available balance is {money(balance, cur)}.")

    top = highest = None
    if m_exp:
        totals = _cat_totals(m_exp)
        name, amount = max(totals.items(), key=lambda kv: (kv[1], kv[0]))
        top = {"category": name, "amount": fmt(amount), "share_percent": round(amount * 100 / m_spent)}
        s.append(f"Your biggest spending category this month is {name}, accounting for "
                 f"{top['share_percent']}% of your expenses.")
        h = max(m_exp, key=lambda r: (r["amount_cents"], r["date"]))
        highest = {"name": h["name"], "amount": fmt(h["amount_cents"]), "category": h["category"],
                   "date": h["date"]}
        s.append(f"Your highest single expense this month was “{h['name']}” at "
                 f"{money(h['amount_cents'], cur)} ({h['category']}).")
        s.append(f"You are averaging {money(avg_daily, cur)} per day this month.")
    elif exp_rows:
        h = max(exp_rows, key=lambda r: (r["amount_cents"], r["date"]))
        highest = {"name": h["name"], "amount": fmt(h["amount_cents"]), "category": h["category"],
                   "date": h["date"]}
        s.append(f"Your highest recorded expense overall was “{h['name']}” at "
                 f"{money(h['amount_cents'], cur)} ({h['category']}).")

    change_pct = None
    if p_spent > 0 and m_spent >= 0:
        change_pct = round((m_spent - p_spent) * 100 / p_spent)
        if abs(change_pct) < 5:
            s.append(f"Your spending is about the same as in the same days of last month "
                     f"({money(p_spent, cur)}).")
        elif change_pct > 0:
            s.append(f"Your spending has increased by {change_pct}% compared with the same days of "
                     f"last month ({money(p_spent, cur)}).")
        else:
            s.append(f"Your spending has decreased by {abs(change_pct)}% compared with the same days "
                     f"of last month ({money(p_spent, cur)}).")
        mt, pt = _cat_totals(m_exp), _cat_totals(p_exp)
        deltas = {c: mt.get(c, 0) - pt.get(c, 0) for c in set(mt) | set(pt)}
        if deltas:
            c, dv = max(deltas.items(), key=lambda kv: (abs(kv[1]), kv[0]))
            if dv != 0:
                s.append(f"The biggest change in your habits is {c}, where spending is "
                         f"{'up' if dv > 0 else 'down'} by {money(abs(dv), cur)}.")
    elif m_spent > 0:
        s.append("There is no spending from the same days of last month to compare with yet.")

    s.append(f"Since you started tracking, you have spent {money(total_exp, cur)} and received "
             f"{money(total_inc, cur)} in total.")
    for b in budget_items:
        if b["state"] == "exceeded":
            s.append(f"You have gone over your {b['category']} budget by "
                     f"{money(-b['remaining_cents'], cur)}.")
        elif b["state"] == "warning":
            s.append(f"You have used {round(b['percent_used'])}% of your {b['category']} budget.")

    sufficient = len(exp_rows) >= 3
    if not sufficient:
        s.append("Record a few more expenses to unlock more reliable trends and comparisons.")

    facts["month"] = {"label": month_name, "spent": fmt(m_spent), "income": fmt(m_inc_total),
                      "expense_count": len(m_exp), "average_daily": fmt(avg_daily),
                      "top_category": top, "highest_expense": highest}
    facts["previous_period_spent"] = fmt(p_spent) if p_spent else None
    facts["change_percent"] = change_pct
    return {"paragraph": " ".join(s), "sufficient_data": sufficient, "facts": facts}
