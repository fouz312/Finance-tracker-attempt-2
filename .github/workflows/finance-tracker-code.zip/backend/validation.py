"""Strict input validation. Money is parsed with Decimal and converted to integer cents."""
import re
from datetime import date
from decimal import Decimal, InvalidOperation

EXPENSE_CATEGORIES = ["Food", "Shopping", "Transportation", "Entertainment", "Education",
                      "Technology", "Bills", "Subscriptions", "Healthcare", "Other"]
INCOME_CATEGORIES = ["Salary", "Allowance", "Gifts", "Freelance", "Other Income"]
PAYMENT_METHODS = ["Cash", "Card", "Bank Transfer", "Apple Pay", "Other"]

MAX_AMOUNT = Decimal("1000000000")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


class ApiError(Exception):
    def __init__(self, status, code, message, details=None):
        super().__init__(message)
        self.status, self.code, self.message, self.details = status, code, message, details


def bad(message, field=None):
    return ApiError(400, "validation_error", message, {"field": field} if field else None)


def parse_money(value, field, *, allow_negative=False):
    """Accepts a JSON number or numeric string with at most 2 decimals; returns integer cents."""
    if value is None or isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise bad(f"{field} must be a number", field)
    try:
        d = Decimal(str(value).strip())
    except InvalidOperation:
        raise bad(f"{field} must be a number", field)
    if not d.is_finite():
        raise bad(f"{field} must be a finite number", field)
    if abs(d) > MAX_AMOUNT:
        raise bad(f"{field} is too large", field)
    if d != d.quantize(Decimal("0.01")):
        raise bad(f"{field} can have at most 2 decimal places", field)
    if d < 0 and not allow_negative:
        raise bad(f"{field} must not be negative", field)
    return int((d * 100).to_integral_value())


def parse_text(value, field, *, max_len, min_len=0, default=None):
    if value is None:
        if default is not None:
            return default
        raise bad(f"{field} is required", field)
    if not isinstance(value, str):
        raise bad(f"{field} must be a string", field)
    v = value.strip()
    if any(ord(c) < 32 and c not in "\n\t" for c in v):
        raise bad(f"{field} contains invalid characters", field)
    if len(v) < min_len or len(v) > max_len:
        raise bad(f"{field} must be {min_len}-{max_len} characters", field)
    return v


def parse_date(value, field, today):
    if not isinstance(value, str) or not DATE_RE.match(value):
        raise bad(f"{field} must be YYYY-MM-DD", field)
    try:
        d = date.fromisoformat(value)
    except ValueError:
        raise bad(f"{field} is not a valid date", field)
    if d.year < 1970:
        raise bad(f"{field} is too far in the past", field)
    return d


def validate_id(value, field="id"):
    if not isinstance(value, str) or not ID_RE.match(value):
        raise bad(f"{field} must be 8-64 characters of letters, digits, '-' or '_'", field)
    return value


def validate_transaction(p, today):
    if not isinstance(p, dict):
        raise bad("Transaction must be a JSON object")
    t = p.get("type")
    if t not in ("expense", "income"):
        raise bad("type must be 'expense' or 'income'", "type")
    cats = EXPENSE_CATEGORIES if t == "expense" else INCOME_CATEGORIES
    if p.get("category") not in cats:
        raise bad(f"category for {t} must be one of: {', '.join(cats)}", "category")
    cents = parse_money(p.get("amount"), "amount")
    if cents <= 0:
        raise bad("amount must be greater than 0", "amount")
    d = parse_date(p.get("date"), "date", today)
    if d > today:
        raise bad("date cannot be in the future", "date")
    method = p.get("payment_method", "Other")
    if method not in PAYMENT_METHODS:
        raise bad(f"payment_method must be one of: {', '.join(PAYMENT_METHODS)}", "payment_method")
    return {
        "type": t,
        "name": parse_text(p.get("name"), "name", min_len=1, max_len=100),
        "amount_cents": cents,
        "category": p["category"],
        "date": d.isoformat(),
        "description": parse_text(p.get("description"), "description", max_len=500, default=""),
        "payment_method": method,
    }


def validate_wallet(p, partial=False):
    if not isinstance(p, dict):
        raise bad("wallet must be a JSON object", "wallet")
    out = {}
    if "name" in p or not partial:
        out["name"] = parse_text(p.get("name"), "name", min_len=1, max_len=50)
    if "currency" in p or not partial:
        cur = p.get("currency")
        cur = cur.strip().upper() if isinstance(cur, str) else cur
        if not isinstance(cur, str) or not CURRENCY_RE.match(cur):
            raise bad("currency must be a 3-letter ISO code such as AED", "currency")
        out["currency"] = cur
    if "starting_balance" in p or not partial:
        out["starting_balance_cents"] = parse_money(p.get("starting_balance"), "starting_balance",
                                                    allow_negative=True)
    if partial and not out:
        raise bad("Provide at least one of: name, currency, starting_balance")
    return out


def validate_email(value):
    if not isinstance(value, str):
        raise bad("email is required", "email")
    v = value.strip().lower()
    if len(v) > 254 or not EMAIL_RE.match(v):
        raise bad("email is not valid", "email")
    return v


def validate_password(value):
    if not isinstance(value, str) or not (8 <= len(value) <= 128):
        raise bad("password must be 8-128 characters", "password")
    return value
