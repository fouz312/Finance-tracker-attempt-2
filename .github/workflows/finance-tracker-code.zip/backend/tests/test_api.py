import json
import os
import sqlite3
import tempfile
import unittest
from datetime import date, datetime, timedelta, timezone

from app import create_app

PW = "correct-horse-battery"


def today():
    return datetime.now(timezone.utc).date()


def iso(d):
    return d.isoformat()


class Base(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DB_PATH": self.path, "JWT_SECRET": "x" * 40, "REQUIRE_HTTPS": False,
                               "LOGIN_MAX_ATTEMPTS": 3})
        self.c = self.app.test_client()

    def tearDown(self):
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(self.path + suffix)
            except FileNotFoundError:
                pass

    def register(self, email="a@example.com", balance="5000", currency="AED", name="My Wallet"):
        r = self.c.post("/api/v1/auth/register", json={
            "email": email, "password": PW,
            "wallet": {"name": name, "currency": currency, "starting_balance": balance}})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()

    def hdr(self, reg):
        return {"Authorization": "Bearer " + reg["access_token"]}

    def add(self, reg, type_, amount, category, d=None, name="Item", **extra):
        body = {"type": type_, "name": name, "amount": amount, "category": category,
                "date": iso(d or today()), "payment_method": "Card", **extra}
        r = self.c.post("/api/v1/transactions", json=body, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()

    def get(self, reg, path):
        r = self.c.get("/api/v1" + path, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class AuthTests(Base):
    def test_register_login_and_unauthorized(self):
        reg = self.register()
        self.assertEqual(reg["wallet"], {"name": "My Wallet", "currency": "AED", "starting_balance": "5000.00"})
        self.assertEqual(self.c.get("/api/v1/balance").status_code, 401)
        self.assertEqual(self.c.get("/api/v1/balance", headers={"Authorization": "Bearer junk"}).status_code, 401)
        r = self.c.post("/api/v1/auth/login", json={"email": "A@Example.com", "password": PW})
        self.assertEqual(r.status_code, 200)
        r = self.c.post("/api/v1/auth/login", json={"email": "a@example.com", "password": "nope"})
        self.assertEqual(r.status_code, 401)

    def test_duplicate_email_and_weak_password(self):
        self.register()
        wallet = {"name": "w", "currency": "AED", "starting_balance": "1"}
        r = self.c.post("/api/v1/auth/register", json={"email": "a@example.com", "password": PW, "wallet": wallet})
        self.assertEqual(r.status_code, 409)
        r = self.c.post("/api/v1/auth/register", json={"email": "b@example.com", "password": "short", "wallet": wallet})
        self.assertEqual(r.status_code, 400)

    def test_password_is_not_stored_in_plain_text(self):
        self.register()
        h = sqlite3.connect(self.path).execute("SELECT password_hash FROM users").fetchone()[0]
        self.assertTrue(h.startswith("scrypt$"))
        self.assertNotIn(PW, h)

    def test_login_throttling(self):
        self.register()
        for _ in range(3):
            r = self.c.post("/api/v1/auth/login", json={"email": "a@example.com", "password": "bad"})
            self.assertEqual(r.status_code, 401)
        r = self.c.post("/api/v1/auth/login", json={"email": "a@example.com", "password": PW})
        self.assertEqual(r.status_code, 429)

    def test_refresh_rotation_and_reuse_detection(self):
        reg = self.register()
        r1 = self.c.post("/api/v1/auth/refresh", json={"refresh_token": reg["refresh_token"]})
        self.assertEqual(r1.status_code, 200)
        new = r1.get_json()
        # replaying the old (rotated) token fails and also kills the new one
        r = self.c.post("/api/v1/auth/refresh", json={"refresh_token": reg["refresh_token"]})
        self.assertEqual(r.status_code, 401)
        r = self.c.post("/api/v1/auth/refresh", json={"refresh_token": new["refresh_token"]})
        self.assertEqual(r.status_code, 401)

    def test_logout_revokes_refresh_token(self):
        reg = self.register()
        r = self.c.post("/api/v1/auth/logout", json={"refresh_token": reg["refresh_token"]})
        self.assertEqual(r.status_code, 204)
        r = self.c.post("/api/v1/auth/refresh", json={"refresh_token": reg["refresh_token"]})
        self.assertEqual(r.status_code, 401)

    def test_https_enforced_when_enabled(self):
        app = create_app({"DB_PATH": self.path, "JWT_SECRET": "x" * 40, "REQUIRE_HTTPS": True})
        c = app.test_client()
        self.assertEqual(c.post("/api/v1/auth/login", json={}).status_code, 403)
        self.assertEqual(c.get("/health").status_code, 200)
        r = c.post("/api/v1/auth/login", json={}, base_url="https://localhost")
        self.assertEqual(r.status_code, 400)  # got past the HTTPS gate; fails normal validation

    def test_missing_secret_refuses_to_start(self):
        with self.assertRaises(RuntimeError):
            create_app({"DB_PATH": self.path, "JWT_SECRET": "short"})

    def test_delete_account_removes_everything(self):
        reg = self.register()
        self.add(reg, "expense", "10", "Food")
        r = self.c.delete("/api/v1/me", json={"password": "wrong"}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 403)
        r = self.c.delete("/api/v1/me", json={"password": PW}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 204)
        self.assertEqual(self.c.get("/api/v1/balance", headers=self.hdr(reg)).status_code, 401)
        db = sqlite3.connect(self.path)
        for t in ("users", "wallets", "transactions", "refresh_tokens"):
            self.assertEqual(db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0], 0, t)


class BalanceTests(Base):
    def test_spec_example_balance(self):
        reg = self.register(balance="5000")
        self.add(reg, "income", "1000", "Salary")
        self.add(reg, "expense", "1500", "Shopping")
        b = self.get(reg, "/balance")
        self.assertEqual((b["starting_balance"], b["total_income"], b["total_expenses"], b["balance"]),
                         ("5000.00", "1000.00", "1500.00", "4500.00"))
        self.assertEqual(b["transaction_count"], 2)

    def test_edit_and_delete_update_balance(self):
        reg = self.register(balance="100")
        tx = self.add(reg, "expense", "30.10", "Food")
        self.assertEqual(self.get(reg, "/balance")["balance"], "69.90")
        r = self.c.put(f"/api/v1/transactions/{tx['id']}", json={**tx, "amount": "10.00"}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.get(reg, "/balance")["balance"], "90.00")
        r = self.c.delete(f"/api/v1/transactions/{tx['id']}", headers=self.hdr(reg))
        self.assertEqual(r.status_code, 204)
        self.assertEqual(self.get(reg, "/balance")["balance"], "100.00")

    def test_no_floating_point_drift(self):
        reg = self.register(balance="0")
        for _ in range(10):
            self.add(reg, "income", "0.10", "Gifts")
        self.assertEqual(self.get(reg, "/balance")["balance"], "1.00")

    def test_week_and_month_spending(self):
        reg = self.register()
        self.add(reg, "expense", "20", "Food", today())
        self.add(reg, "expense", "50", "Food", today() - timedelta(days=400))
        b = self.get(reg, "/balance")
        self.assertEqual(b["spent_this_week"], "20.00")
        self.assertEqual(b["spent_this_month"], "20.00")
        self.assertEqual(b["total_expenses"], "70.00")

    def test_changing_wallet_settings_never_touches_transactions(self):
        reg = self.register(balance="100")
        self.add(reg, "expense", "40", "Food")
        r = self.c.put("/api/v1/wallet", json={"starting_balance": "500", "currency": "usd", "name": "Main"},
                       headers=self.hdr(reg))
        self.assertEqual(r.get_json(), {"name": "Main", "currency": "USD", "starting_balance": "500.00"})
        b = self.get(reg, "/balance")
        self.assertEqual((b["transaction_count"], b["balance"]), (1, "460.00"))


class TransactionTests(Base):
    def test_validation(self):
        reg = self.register()
        h = self.hdr(reg)
        good = {"type": "expense", "name": "x", "amount": "5", "category": "Food", "date": iso(today())}

        def post(**kw):
            return self.c.post("/api/v1/transactions", json={**good, **kw}, headers=h).status_code

        self.assertEqual(post(), 201)
        for bad in [{"amount": "-5"}, {"amount": "0"}, {"amount": "1.234"}, {"amount": "abc"}, {"amount": True},
                    {"amount": "1e30"}, {"amount": "NaN"}, {"category": "Salary"}, {"category": "Nope"},
                    {"type": "transfer"}, {"name": ""}, {"name": "x" * 101}, {"date": "2024-13-01"},
                    {"date": "20240101"}, {"date": iso(today() + timedelta(days=5))},
                    {"payment_method": "Bitcoin"}, {"id": "../etc"}]:
            self.assertEqual(post(**bad), 400, bad)
        self.assertEqual(post(type="income", category="Salary"), 201)

    def test_users_are_isolated(self):
        a, b = self.register("a@example.com"), self.register("b@example.com")
        tx = self.add(a, "expense", "99", "Food")
        self.assertEqual(self.c.get(f"/api/v1/transactions/{tx['id']}", headers=self.hdr(b)).status_code, 404)
        self.assertEqual(self.get(b, "/transactions")["total"], 0)
        # B "upserting" A's id creates B's own row and leaves A's untouched
        body = {"type": "expense", "name": "mine", "amount": "1", "category": "Food", "date": iso(today())}
        r = self.c.put(f"/api/v1/transactions/{tx['id']}", json=body, headers=self.hdr(b))
        self.assertEqual(r.status_code, 201)
        self.assertEqual(self.get(a, f"/transactions/{tx['id']}")["amount"], "99.00")
        self.c.delete(f"/api/v1/transactions/{tx['id']}", headers=self.hdr(b))
        self.assertEqual(self.get(a, f"/transactions/{tx['id']}")["name"], "Item")
        self.assertEqual(self.get(a, "/balance")["balance"], "4901.00")

    def test_idempotent_put_and_delete_for_offline_sync(self):
        reg = self.register()
        body = {"type": "expense", "name": "x", "amount": "5", "category": "Food", "date": iso(today())}
        tid = "11111111-2222-3333-4444-555555555555"
        self.assertEqual(self.c.put(f"/api/v1/transactions/{tid}", json=body, headers=self.hdr(reg)).status_code, 201)
        self.assertEqual(self.c.put(f"/api/v1/transactions/{tid}", json=body, headers=self.hdr(reg)).status_code, 200)
        self.assertEqual(self.get(reg, "/transactions")["total"], 1)
        for _ in range(2):
            self.assertEqual(self.c.delete(f"/api/v1/transactions/{tid}", headers=self.hdr(reg)).status_code, 204)
        r = self.c.post("/api/v1/transactions", json={**body, "id": "abcdefgh1"}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 201)
        r = self.c.post("/api/v1/transactions", json={**body, "id": "abcdefgh1"}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 409)

    def test_search_filter_sort_pagination(self):
        reg = self.register()
        self.add(reg, "expense", "10", "Food", today(), name="Coffee")
        self.add(reg, "expense", "300", "Shopping", today() - timedelta(days=3), name="Shoes")
        self.add(reg, "income", "1000", "Salary", today() - timedelta(days=5), name="Pay")
        self.add(reg, "expense", "5", "Food", today() - timedelta(days=40), name="100% juice")

        def names(q):
            return [t["name"] for t in self.get(reg, "/transactions?" + q)["items"]]

        self.assertEqual(names("q=coff"), ["Coffee"])
        self.assertEqual(names("q=%25"), ["100% juice"])  # LIKE wildcards are escaped
        self.assertEqual(names("q=_"), [])
        self.assertEqual(names("type=income"), ["Pay"])
        self.assertEqual(names("category=Food&sort=oldest"), ["100% juice", "Coffee"])
        self.assertEqual(names("sort=highest"), ["Pay", "Shoes", "Coffee", "100% juice"])
        self.assertEqual(names("sort=lowest")[0], "100% juice")
        self.assertEqual(names(f"from={iso(today() - timedelta(days=10))}&sort=oldest"), ["Pay", "Shoes", "Coffee"])
        page = self.get(reg, "/transactions?limit=2&offset=2&sort=newest")
        self.assertEqual((len(page["items"]), page["total"]), (2, 4))
        self.assertEqual(self.c.get("/api/v1/transactions?sort=bad", headers=self.hdr(reg)).status_code, 400)
        self.assertEqual(self.c.get("/api/v1/transactions?limit=9999", headers=self.hdr(reg)).status_code, 400)


class AnalyticsTests(Base):
    def seed(self):
        reg = self.register(balance="1000")
        self.add(reg, "expense", "100", "Food", today(), name="Lunch")
        self.add(reg, "expense", "300", "Shopping", today() - timedelta(days=2), name="Jacket")
        self.add(reg, "income", "500", "Salary", today() - timedelta(days=3))
        self.add(reg, "expense", "50", "Bills", today() - timedelta(days=45))
        return reg

    def test_spending_over_time_matches_database(self):
        reg = self.seed()
        d = self.get(reg, "/analytics/spending-over-time?range=30d&granularity=day")
        self.assertEqual(len(d["points"]), 30)
        self.assertEqual(d["total"], "400.00")
        self.assertEqual(sum(float(p["amount"]) for p in d["points"]), 400.0)
        self.assertEqual(d["points"][-1]["amount"], "100.00")
        for g in ("day", "week", "month", "year"):
            r = self.get(reg, f"/analytics/spending-over-time?range=3m&granularity={g}")
            self.assertEqual(r["total"], "450.00", g)
        self.assertEqual(self.get(reg, "/analytics/spending-over-time?range=all")["total"], "450.00")
        self.assertEqual(self.get(reg, "/analytics/spending-over-time?range=7d")["total"], "400.00")

    def test_category_breakdown(self):
        reg = self.seed()
        d = self.get(reg, "/analytics/by-category?range=30d")
        self.assertEqual([(c["category"], c["amount"], c["share_percent"]) for c in d["categories"]],
                         [("Shopping", "300.00", 75.0), ("Food", "100.00", 25.0)])
        self.assertEqual(d["total"], "400.00")

    def test_income_vs_expenses(self):
        reg = self.seed()
        d = self.get(reg, "/analytics/income-vs-expenses?range=30d&granularity=month")
        self.assertEqual((d["total_income"], d["total_expenses"]), ("500.00", "400.00"))

    def test_balance_history_ends_at_current_balance_and_includes_pre_range_history(self):
        reg = self.seed()
        cur = self.get(reg, "/balance")["balance"]
        for rng in ("7d", "30d", "3m", "all"):
            pts = self.get(reg, f"/analytics/balance-history?range={rng}")["points"]
            self.assertEqual(pts[-1]["balance"], cur, rng)
        # the 45-day-old 50 bill is before the 7d window, so the window opens at 1000 - 50
        pts = self.get(reg, "/analytics/balance-history?range=7d")["points"]
        self.assertEqual(pts[0]["balance"], "950.00")

    def test_empty_account_analytics(self):
        reg = self.register()
        self.assertEqual(self.get(reg, "/analytics/by-category?range=all")["categories"], [])
        self.assertEqual(self.get(reg, "/analytics/spending-over-time?range=all")["total"], "0.00")
        self.assertEqual(self.get(reg, "/analytics/balance-history?range=all")["points"][-1]["balance"], "5000.00")

    def test_invalid_params(self):
        reg = self.register()
        for q in ("range=2y", "granularity=hour"):
            r = self.c.get("/api/v1/analytics/spending-over-time?" + q, headers=self.hdr(reg))
            self.assertEqual(r.status_code, 400)

    def test_downsampled_long_history_keeps_final_point(self):
        reg = self.register(balance="0")
        self.add(reg, "income", "10", "Gifts", date(2015, 1, 1))
        self.add(reg, "expense", "3", "Food", today())
        pts = self.get(reg, "/analytics/balance-history?range=all")["points"]
        self.assertLessEqual(len(pts), 201)
        self.assertEqual(pts[-1]["balance"], "7.00")
        self.assertEqual(pts[-1]["date"], iso(today()))


class SummaryTests(Base):
    def test_empty_account_says_no_data(self):
        reg = self.register(balance="5000")
        s = self.get(reg, "/summary")
        self.assertFalse(s["sufficient_data"])
        self.assertIn("haven't recorded any transactions", s["paragraph"])
        self.assertIn("5,000 AED", s["paragraph"])

    def test_summary_uses_only_real_data(self):
        reg = self.register(balance="5000")
        ms = today().replace(day=1)
        pm_start = (ms - timedelta(days=1)).replace(day=1)
        self.add(reg, "expense", "400", "Shopping", today(), name="Sneakers")
        self.add(reg, "expense", "100", "Food", today(), name="Dinner")
        self.add(reg, "income", "500", "Freelance", today())
        self.add(reg, "expense", "250", "Food", pm_start, name="Old groceries")
        s = self.get(reg, "/summary")
        p = s["paragraph"]
        self.assertIn("Your starting balance was 5,000 AED", p)
        self.assertIn("spent 500 AED across 2 expenses and received 500 AED in income", p)
        self.assertIn("current available balance is 4,750 AED", p)
        self.assertIn("biggest spending category this month is Shopping, accounting for 80%", p)
        self.assertIn("“Sneakers” at 400 AED", p)
        self.assertIn("increased by 100%", p)  # 500 this month vs 250 over the same days last month
        self.assertIn("Since you started tracking, you have spent 750 AED and received 500 AED", p)
        self.assertNotIn("Old groceries", p)
        # only 3 expenses recorded in total -> trends are flagged as thin and the paragraph says so
        self.assertTrue(s["sufficient_data"])
        f = s["facts"]
        self.assertEqual((f["month"]["spent"], f["current_balance"], f["change_percent"]),
                         ("500.00", "4750.00", 100))

    def test_thin_data_is_called_out(self):
        reg = self.register()
        self.add(reg, "expense", "10", "Food")
        s = self.get(reg, "/summary")
        self.assertFalse(s["sufficient_data"])
        self.assertIn("Record a few more expenses", s["paragraph"])
        self.assertIn("no spending from the same days of last month", s["paragraph"])

    def test_budget_alerts_in_summary(self):
        reg = self.register()
        self.add(reg, "expense", "150", "Food", today())
        self.c.put("/api/v1/budgets/Food", json={"limit": "100"}, headers=self.hdr(reg))
        self.assertIn("gone over your Food budget by 50 AED", self.get(reg, "/summary")["paragraph"])


class BudgetTests(Base):
    def test_budget_lifecycle_and_status(self):
        reg = self.register()
        h = self.hdr(reg)
        self.assertEqual(self.c.put("/api/v1/budgets/Food", json={"limit": "500"}, headers=h).status_code, 200)
        self.assertEqual(self.c.put("/api/v1/budgets/Nope", json={"limit": "5"}, headers=h).status_code, 400)
        self.assertEqual(self.c.put("/api/v1/budgets/Food", json={"limit": "-5"}, headers=h).status_code, 400)
        self.c.put("/api/v1/budgets/Shopping", json={"limit": "100"}, headers=h)
        self.c.put("/api/v1/budgets/Bills", json={"limit": "100"}, headers=h)
        self.add(reg, "expense", "125", "Food")
        self.add(reg, "expense", "90", "Shopping")
        self.add(reg, "expense", "120", "Bills")
        items = {i["category"]: i for i in self.get(reg, "/budgets/status")["items"]}
        self.assertEqual((items["Food"]["state"], items["Food"]["percent_used"], items["Food"]["remaining"]),
                         ("ok", 25.0, "375.00"))
        self.assertEqual(items["Shopping"]["state"], "warning")
        self.assertEqual((items["Bills"]["state"], items["Bills"]["remaining"]), ("exceeded", "-20.00"))
        self.assertEqual(self.c.delete("/api/v1/budgets/Food", headers=h).status_code, 204)
        self.assertEqual(len(self.get(reg, "/budgets")["items"]), 2)


class ExportBackupTests(Base):
    def test_csv_export_blocks_formula_injection(self):
        reg = self.register()
        self.add(reg, "expense", "5", "Food", name="=HYPERLINK(\"http://evil\")")
        r = self.c.get("/api/v1/export/csv", headers=self.hdr(reg))
        text = r.get_data(as_text=True)
        self.assertEqual(r.mimetype, "text/csv")
        self.assertIn("id,date,type,name", text)
        self.assertIn("'=HYPERLINK", text)
        self.assertNotIn(",=HYPERLINK", text)

    def test_backup_and_restore_roundtrip(self):
        reg = self.register(balance="100")
        self.add(reg, "expense", "10", "Food", name="A")
        self.add(reg, "income", "40", "Gifts", name="B")
        self.c.put("/api/v1/budgets/Food", json={"limit": "50"}, headers=self.hdr(reg))
        backup = json.loads(self.c.get("/api/v1/backup", headers=self.hdr(reg)).get_data(as_text=True))
        self.assertEqual(len(backup["transactions"]), 2)
        other = self.register("b@example.com", balance="1", currency="USD")
        r = self.c.post("/api/v1/restore", json={"mode": "replace", "backup": backup}, headers=self.hdr(other))
        self.assertEqual(r.get_json(), {"restored_transactions": 2, "restored_budgets": 1})
        b = self.get(other, "/balance")
        self.assertEqual((b["balance"], b["currency"], b["transaction_count"]), ("130.00", "AED", 2))
        for _ in range(2):  # merging the same backup twice is idempotent
            self.c.post("/api/v1/restore", json={"mode": "merge", "backup": backup}, headers=self.hdr(other))
        self.assertEqual(self.get(other, "/balance")["transaction_count"], 2)
        self.assertEqual(self.get(reg, "/balance")["balance"], "130.00")  # original user untouched

    def test_restore_rejects_bad_data_atomically(self):
        reg = self.register()
        self.add(reg, "expense", "10", "Food")
        bad = {"version": 1, "transactions": [
            {"id": "goodid123", "type": "expense", "name": "ok", "amount": "1", "category": "Food",
             "date": iso(today())},
            {"id": "badid1234", "type": "expense", "name": "bad", "amount": "-1", "category": "Food",
             "date": iso(today())}]}
        r = self.c.post("/api/v1/restore", json={"mode": "replace", "backup": bad}, headers=self.hdr(reg))
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.get(reg, "/balance")["transaction_count"], 1)  # nothing was wiped


if __name__ == "__main__":
    unittest.main()
