"""SQLite persistence. Money is stored as integer cents; every row is scoped by user_id."""
import sqlite3

from flask import current_app, g

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS users(
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS wallets(
  user_id                TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  name                   TEXT NOT NULL,
  currency               TEXT NOT NULL,
  starting_balance_cents INTEGER NOT NULL,
  created_at             TEXT NOT NULL,
  updated_at             TEXT NOT NULL
);

-- Primary key is (user_id, id): two users can never collide on, read, or overwrite each other's ids.
CREATE TABLE IF NOT EXISTS transactions(
  id             TEXT NOT NULL,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type           TEXT NOT NULL CHECK(type IN ('expense','income')),
  name           TEXT NOT NULL,
  amount_cents   INTEGER NOT NULL CHECK(amount_cents > 0),
  category       TEXT NOT NULL,
  date           TEXT NOT NULL,
  description    TEXT NOT NULL DEFAULT '',
  payment_method TEXT NOT NULL DEFAULT 'Other',
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL,
  PRIMARY KEY(user_id, id)
);
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);

CREATE TABLE IF NOT EXISTS budgets(
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category    TEXT NOT NULL,
  limit_cents INTEGER NOT NULL CHECK(limit_cents > 0),
  updated_at  TEXT NOT NULL,
  PRIMARY KEY(user_id, category)
);

CREATE TABLE IF NOT EXISTS refresh_tokens(
  token_hash TEXT PRIMARY KEY,          -- SHA-256 of the opaque token; the token itself is never stored
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  revoked    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS login_attempts(
  key TEXT NOT NULL,
  at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(key, at);
"""


def get_db():
    if "db" not in g:
        conn = sqlite3.connect(current_app.config["DB_PATH"], timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        g.db = conn
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db(app):
    with app.app_context():
        db = get_db()
        db.executescript(SCHEMA)
        db.commit()
