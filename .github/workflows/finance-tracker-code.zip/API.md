# Finance Tracker API (v1)

Base URL: `https://<your-domain>/api/v1` · JSON in/out · all endpoints except `/auth/*` and `/health` need
`Authorization: Bearer <access_token>`.

**Conventions**
- Amounts are strings with 2 decimals (`"1250.50"`); requests may send a string or number with at most 2 decimals.
- Dates are `YYYY-MM-DD`. Send `X-Client-Date: YYYY-MM-DD` (the device's local date) so "today / this week / this month"
  match the user's timezone. Weeks start on Monday. Future-dated transactions are rejected.
- Errors: `{"error": {"code": "...", "message": "...", "details": {"field": "..."}}}`.
  Statuses: 400 validation · 401 auth · 403 forbidden / HTTPS required · 404 · 409 conflict · 429 throttled · 500.
- Expense categories: Food, Shopping, Transportation, Entertainment, Education, Technology, Bills, Subscriptions, Healthcare, Other.
  Income categories: Salary, Allowance, Gifts, Freelance, Other Income.
  Payment methods: Cash, Card, Bank Transfer, Apple Pay, Other.
- Access tokens last 15 minutes; refresh tokens last 60 days and rotate on every use.

## Auth
| Endpoint | Body | Result |
|---|---|---|
| `POST /auth/register` | `{email, password (8-128 chars), wallet:{name, currency (3-letter code), starting_balance}}` | 201 `{user, wallet, access_token, refresh_token}`; 409 if email taken |
| `POST /auth/login` | `{email, password}` | 200 same shape; 401 bad credentials; 429 after 10 failures in 15 min |
| `POST /auth/refresh` | `{refresh_token}` | 200 `{access_token, refresh_token}`. Replaying an old token revokes all sessions |
| `POST /auth/logout` | `{refresh_token}` | 204 |
| `GET /me` | – | `{id, email, created_at}` |
| `DELETE /me` | `{password}` | 204. Permanently deletes the account, wallet, transactions, budgets and tokens |

## Wallet and balance
| Endpoint | Body | Result |
|---|---|---|
| `GET /wallet` | – | `{name, currency, starting_balance}` |
| `PUT /wallet` | any of `name, currency, starting_balance` | Updated wallet. **Never modifies transactions.** |
| `GET /balance` | – | `{currency, starting_balance, total_income, total_expenses, balance, transaction_count, spent_this_week, spent_this_month, as_of}` where `balance = starting_balance + total_income − total_expenses` |

## Transactions
Body fields: `type` (`expense` or `income`), `name` (1-100 chars), `amount` (> 0), `category`, `date`, `payment_method` (optional), `description` (≤ 500 chars, optional).

| Endpoint | Input | Result |
|---|---|---|
| `GET /transactions` | query: `q` (searches name/description/category), `type`, `category`, `from`, `to`, `sort` (`newest`, `oldest`, `highest`, `lowest`), `limit` (1-500, default 100), `offset` | `{items, total, limit, offset}` |
| `POST /transactions` | body, plus optional client `id` | 201 transaction; 409 if the id exists |
| `GET /transactions/{id}` | – | transaction, or 404 |
| `PUT /transactions/{id}` | full body | **Idempotent upsert** (201 created / 200 updated). Used to replay offline changes |
| `DELETE /transactions/{id}` | – | 204, idempotent |

## Analytics
Common query parameters: `range` = `7d`, `30d`, `3m`, `6m`, `1y` or `all` (default `30d`); `granularity` = `day`, `week`, `month` or `year` (default chosen from the range).

| Endpoint | Result |
|---|---|
| `GET /analytics/spending-over-time` | `{range, granularity, start, end, total, points:[{bucket, start, amount}]}`; empty buckets are included as 0 |
| `GET /analytics/income-vs-expenses` | `{..., total_income, total_expenses, points:[{bucket, start, income, expenses}]}` |
| `GET /analytics/by-category` | `{total, categories:[{category, amount, share_percent, count}]}` (expenses only, largest first) |
| `GET /analytics/balance-history` | `{points:[{date, balance}]}`: end-of-day balance, including everything before the range start |
| `GET /summary` | `{paragraph, sufficient_data, facts{...}, generated_at}`: the written summary, computed from stored rows only |

## Budgets (monthly, per expense category)
| Endpoint | Body | Result |
|---|---|---|
| `GET /budgets` | – | `{items:[{category, limit}]}` |
| `PUT /budgets/{category}` | `{limit}` (> 0) | Create or update |
| `DELETE /budgets/{category}` | – | 204 |
| `GET /budgets/status` | – | `{month, items:[{category, limit, spent, remaining, percent_used, state}]}`; `state` is `ok`, `warning` (≥ 80 %) or `exceeded` (> 100 %) |

## Export, backup, restore
| Endpoint | Body | Result |
|---|---|---|
| `GET /export/csv` | – | `transactions.csv`. Text cells starting with `= + - @` are prefixed with `'` to prevent spreadsheet formula injection |
| `GET /backup` | – | JSON `{version:1, wallet, transactions, budgets}` |
| `POST /restore` | `{mode: "merge" or "replace", backup:{...}}` | `{restored_transactions, restored_budgets}`. All-or-nothing. `replace` first wipes transactions and budgets and restores the wallet |

## Other
`GET /health` returns `{"status":"ok"}` (no auth; allowed over plain HTTP for load-balancer checks).
